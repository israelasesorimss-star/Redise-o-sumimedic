import type { Metadata } from "next";
import { AlertTriangle, BarChart3, BriefcaseBusiness, CircleDollarSign, FileCheck2, Network, RefreshCw, ShieldCheck, Truck, Workflow } from "lucide-react";
import { CtaBand } from "@/components/cta-band";
import { SectionHeading } from "@/components/section-heading";
import { b2bSegments, processFlow } from "@/lib/data";

export const metadata: Metadata = {
  title: "Area B2B para hospitales, gobierno y clinicas",
  description:
    "Soluciones para clientes institucionales, gobierno, hospitales, licitaciones, compras recurrentes, convenios empresariales y automatizacion comercial.",
  alternates: { canonical: "/b2b" }
};

const modules = [
  { icon: BriefcaseBusiness, title: "Clientes institucionales", text: "Perfiles de compra, listas autorizadas, precios por cuenta y condiciones comerciales." },
  { icon: FileCheck2, title: "Licitaciones", text: "Documentacion tecnica, fichas, trazabilidad y soporte para gobierno.", id: "licitaciones" },
  { icon: RefreshCw, title: "Compras recurrentes", text: "Reposicion automatizada por consumo, minimos y frecuencia operacional.", id: "compras-recurrentes" },
  { icon: CircleDollarSign, title: "Credito empresarial", text: "Flujos para autorizacion, limite de credito, facturacion y aprobaciones." },
  { icon: Workflow, title: "Automatizacion CRM", text: "Lead scoring, pipeline, tareas, remarketing y seguimiento postcotizacion." },
  { icon: BarChart3, title: "Dashboard ejecutivo", text: "Ventas, margen, conversion, inventario, demanda y desempeno por segmento." }
];

export default function B2BPage() {
  return (
    <main>
      <section className="bg-ink py-16 text-white">
        <div className="container-premium">
          <SectionHeading
            eyebrow="Operacion institucional"
            title="Una plataforma para vender, retener y escalar cuentas medicas."
            text="SUMIMEDIC queda preparada para procesos de compra complejos: aprobaciones, contratos, entregas, soporte documental, CRM y recompra."
            tone="dark"
          />
        </div>
      </section>

      <section className="bg-white py-16">
        <div className="container-premium grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          {b2bSegments.map((segment) => {
            const Icon = segment.icon;
            return (
              <article key={segment.title} className="rounded-md border border-slate-200 p-6 shadow-sm">
                <Icon className="text-clinical" size={30} />
                <h2 className="mt-5 font-[var(--font-manrope)] text-xl font-extrabold">{segment.title}</h2>
                <p className="mt-3 text-sm leading-7 text-slate-600">{segment.text}</p>
              </article>
            );
          })}
        </div>
      </section>

      <section className="bg-sterile py-16">
        <div className="container-premium">
          <SectionHeading
            eyebrow="Modulos de negocio"
            title="Backend comercial pensado para venta B2B real."
            text="La plataforma contempla gestion de productos, inventario, cotizaciones, pedidos, facturacion, CRM, integraciones, analytics y seguridad."
            align="center"
          />
          <div className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            {modules.map((module) => {
              const Icon = module.icon;
              return (
                <article key={module.title} id={module.id} className="rounded-md border border-slate-200 bg-white p-6 shadow-sm">
                  <Icon className="text-clinical" size={28} />
                  <h3 className="mt-4 text-lg font-extrabold text-ink">{module.title}</h3>
                  <p className="mt-2 text-sm leading-7 text-slate-600">{module.text}</p>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      <section className="bg-white py-16">
        <div className="container-premium">
          <SectionHeading eyebrow="Flujo comercial" title="De lead a recompra institucional." align="center" />
          <div className="mt-10 grid gap-4 md:grid-cols-5">
            {processFlow.map((step, index) => (
              <div key={step.title} className="rounded-md border border-slate-200 bg-white p-5 shadow-sm">
                <span className="grid h-9 w-9 place-items-center rounded-md bg-clinical text-sm font-extrabold text-white">
                  {index + 1}
                </span>
                <h3 className="mt-5 font-[var(--font-manrope)] text-lg font-extrabold">{step.title}</h3>
                <p className="mt-3 text-sm leading-7 text-slate-600">{step.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-sterile py-16">
        <div className="container-premium grid gap-10 lg:grid-cols-[1fr_.95fr] lg:items-start">
          <div>
            <SectionHeading
              eyebrow="Area privada B2B"
              title="Gestion de Abastecimiento para cuentas institucionales."
              text="Panel operativo para historial, recurrencia, pedidos abiertos, proveedores asignados, seguimiento, incidencias y reposicion automatica."
            />
            <div className="mt-8 grid gap-4 sm:grid-cols-2">
              {[
                { icon: Network, title: "Proveedores asignados", text: "Red certificada visible solo como trazabilidad operativa SUMIMEDIC." },
                { icon: Truck, title: "Pedidos abiertos", text: "Tracking profesional, SLA, rutas, tiempos estimados y evidencias." },
                { icon: AlertTriangle, title: "Incidencias", text: "Soporte especializado con prioridad por cliente y criticidad medica." },
                { icon: ShieldCheck, title: "Documentacion", text: "Fichas, certificados, garantias y validacion regulatoria descargable." }
              ].map((item) => {
                const Icon = item.icon;
                return (
                  <article key={item.title} className="rounded-md border border-slate-200 bg-white p-5 shadow-sm">
                    <Icon className="text-clinical" size={25} />
                    <h3 className="mt-4 font-extrabold text-ink">{item.title}</h3>
                    <p className="mt-2 text-sm leading-7 text-slate-600">{item.text}</p>
                  </article>
                );
              })}
            </div>
          </div>
          <div className="rounded-md border border-slate-200 bg-white p-6 shadow-premium">
            <p className="mb-5 text-xs font-extrabold uppercase tracking-[0.2em] text-clinical">Dashboard privado</p>
            {[
              ["Recompra automatica", "12 alertas activas"],
              ["Abastecimientos abiertos", "8 pedidos con SLA"],
              ["Proveedores certificados", "4 asignados por categoria"],
              ["Documentos pendientes", "2 validaciones regulatorias"]
            ].map(([label, value]) => (
              <div key={label} className="mb-3 rounded-md border border-slate-200 bg-slate-50 p-4">
                <p className="text-sm font-bold text-slate-500">{label}</p>
                <p className="mt-1 text-2xl font-extrabold text-ink">{value}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      <CtaBand />
    </main>
  );
}
