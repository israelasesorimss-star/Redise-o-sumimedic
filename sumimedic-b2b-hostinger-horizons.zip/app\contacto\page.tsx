import type { Metadata } from "next";
import { Building2, Mail, MapPin, MessageCircle, Phone, Send } from "lucide-react";
import { SectionHeading } from "@/components/section-heading";

export const metadata: Metadata = {
  title: "Contacto y cotizacion",
  description:
    "Formularios inteligentes, integracion CRM, atencion rapida, WhatsApp Business API, sucursales y mapa para compras medicas B2B.",
  alternates: { canonical: "/contacto" }
};

export default function ContactoPage() {
  return (
    <main>
      <section className="bg-radial-depth py-16">
        <div className="container-premium grid gap-10 lg:grid-cols-[.9fr_1.1fr]">
          <SectionHeading
            eyebrow="Cotizacion inmediata"
            title="Conecte con un asesor especializado y active seguimiento CRM."
            text="El formulario esta disenado para calificar cuenta, tipo de compra, urgencia, volumen, segmento y necesidad documental."
          />

          <form className="glass-panel grid gap-4 rounded-md p-6">
            <div className="grid gap-4 md:grid-cols-2">
              <input className="h-12 rounded-md border border-slate-200 px-4 text-sm font-semibold outline-none focus:border-clinical" placeholder="Nombre completo" />
              <input className="h-12 rounded-md border border-slate-200 px-4 text-sm font-semibold outline-none focus:border-clinical" placeholder="Empresa o institucion" />
              <input className="h-12 rounded-md border border-slate-200 px-4 text-sm font-semibold outline-none focus:border-clinical" placeholder="Correo corporativo" />
              <input className="h-12 rounded-md border border-slate-200 px-4 text-sm font-semibold outline-none focus:border-clinical" placeholder="Telefono / WhatsApp" />
            </div>
            <div className="grid gap-4 md:grid-cols-3">
              <select className="h-12 rounded-md border border-slate-200 px-4 text-sm font-semibold outline-none focus:border-clinical">
                <option>Tipo de cliente</option>
                <option>Hospital</option>
                <option>Clinica</option>
                <option>Gobierno</option>
                <option>Laboratorio</option>
                <option>Distribuidor</option>
              </select>
              <select className="h-12 rounded-md border border-slate-200 px-4 text-sm font-semibold outline-none focus:border-clinical">
                <option>Volumen estimado</option>
                <option>Compra unica</option>
                <option>Compra recurrente</option>
                <option>Licitacion</option>
                <option>Contrato marco</option>
              </select>
              <select className="h-12 rounded-md border border-slate-200 px-4 text-sm font-semibold outline-none focus:border-clinical">
                <option>Urgencia</option>
                <option>Inmediata</option>
                <option>7 dias</option>
                <option>30 dias</option>
                <option>Planeacion anual</option>
              </select>
            </div>
            <textarea className="min-h-32 rounded-md border border-slate-200 p-4 text-sm font-semibold outline-none focus:border-clinical" placeholder="Productos, SKUs, cantidades, documentos requeridos o condiciones comerciales" />
            <button className="inline-flex h-14 items-center justify-center gap-2 rounded-md bg-ink px-6 text-sm font-extrabold text-white transition hover:bg-clinical">
              <Send size={18} />
              Enviar a CRM comercial
            </button>
          </form>
        </div>
      </section>

      <section className="bg-white py-16">
        <div className="container-premium grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          {[
            { icon: Phone, title: "Telefono", text: "+52 55 0000 0000" },
            { icon: MessageCircle, title: "WhatsApp B2B", text: "Atencion rapida y seguimiento" },
            { icon: Mail, title: "Correo", text: "ventas@sumimedic.com.mx" },
            { icon: MapPin, title: "Cobertura", text: "Distribucion nacional" }
          ].map((item) => {
            const Icon = item.icon;
            return (
              <article key={item.title} className="rounded-md border border-slate-200 bg-white p-6 shadow-sm">
                <Icon className="text-clinical" size={28} />
                <h2 className="mt-4 text-lg font-extrabold">{item.title}</h2>
                <p className="mt-2 text-sm font-semibold text-slate-500">{item.text}</p>
              </article>
            );
          })}
        </div>
      </section>

      <section className="bg-sterile py-16">
        <div className="container-premium overflow-hidden rounded-md border border-slate-200 bg-white shadow-sm">
          <div className="grid min-h-80 place-items-center bg-medical-grid p-8 text-center">
            <Building2 size={42} className="mb-4 text-clinical" />
            <h2 className="font-[var(--font-manrope)] text-3xl font-extrabold">Mapa y sucursales</h2>
            <p className="mt-3 max-w-xl text-sm leading-7 text-slate-600">
              Bloque preparado para integrar Google Maps, ubicaciones regionales,
              almacenes, rutas de entrega y territorios comerciales.
            </p>
          </div>
        </div>
      </section>
    </main>
  );
}
