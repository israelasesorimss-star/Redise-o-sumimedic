import type { Metadata } from "next";
import { Filter, Search, SlidersHorizontal } from "lucide-react";
import { ProductCard } from "@/components/product-card";
import { SectionHeading } from "@/components/section-heading";
import { CtaBand } from "@/components/cta-band";
import { categories, products } from "@/lib/data";

export const metadata: Metadata = {
  title: "Catalogo B2B de insumos medicos",
  description:
    "Catalogo B2B con filtros avanzados, categorias jerarquicas, busqueda inteligente, comparador, fichas tecnicas y cotizacion institucional.",
  alternates: { canonical: "/catalogo" }
};

export default function CatalogoPage() {
  return (
    <main>
      <section className="bg-radial-depth py-16">
        <div className="container-premium">
          <SectionHeading
            eyebrow="Catalogo inteligente"
            title="Busqueda, filtros y cotizacion para compras B2B."
            text="La experiencia prioriza velocidad de seleccion, fichas tecnicas, comparador, condiciones por cliente y recompra institucional."
          />
          <div className="mt-8 grid gap-4 rounded-md border border-slate-200 bg-white p-4 shadow-premium lg:grid-cols-[1fr_auto_auto]">
            <label className="flex h-14 items-center gap-3 rounded-md border border-slate-200 px-4">
              <Search size={19} className="text-clinical" />
              <input
                className="h-12 w-full bg-transparent text-sm font-semibold outline-none"
                placeholder="Buscar por SKU, categoria, marca, compatibilidad o necesidad clinica"
              />
            </label>
            <button className="inline-flex h-14 items-center justify-center gap-2 rounded-md border border-slate-200 px-5 text-sm font-extrabold text-ink">
              <Filter size={18} />
              Filtros
            </button>
            <button className="inline-flex h-14 items-center justify-center gap-2 rounded-md bg-ink px-5 text-sm font-extrabold text-white">
              <SlidersHorizontal size={18} />
              Comparador
            </button>
          </div>
        </div>
      </section>

      <section className="bg-white py-16">
        <div className="container-premium grid gap-8 lg:grid-cols-[280px_1fr]">
          <aside className="h-fit rounded-md border border-slate-200 bg-slate-50 p-5">
            <h2 className="mb-5 font-[var(--font-manrope)] text-xl font-extrabold">Filtros B2B</h2>
            <div className="grid gap-5">
              <div>
                <p className="mb-3 text-sm font-extrabold text-ink">Categoria</p>
                <div className="grid gap-2">
                  {categories.map((category) => (
                    <label key={category.name} className="flex items-center gap-2 text-sm font-semibold text-slate-600">
                      <input type="checkbox" className="h-4 w-4 accent-clinical" />
                      {category.name}
                    </label>
                  ))}
                </div>
              </div>
              <div>
                <p className="mb-3 text-sm font-extrabold text-ink">Tipo de cliente</p>
                {["Hospital", "Clinica", "Gobierno", "Laboratorio", "Distribuidor"].map((item) => (
                  <label key={item} className="mb-2 flex items-center gap-2 text-sm font-semibold text-slate-600">
                    <input type="checkbox" className="h-4 w-4 accent-clinical" />
                    {item}
                  </label>
                ))}
              </div>
              <div>
                <p className="mb-3 text-sm font-extrabold text-ink">Operacion</p>
                {["Stock inmediato", "Contrato recurrente", "Licitacion", "Credito empresarial"].map((item) => (
                  <label key={item} className="mb-2 flex items-center gap-2 text-sm font-semibold text-slate-600">
                    <input type="checkbox" className="h-4 w-4 accent-clinical" />
                    {item}
                  </label>
                ))}
              </div>
            </div>
          </aside>

          <div>
            <div className="mb-6 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
              <p className="text-sm font-bold text-slate-500">Mostrando productos destacados con datos B2B.</p>
              <select className="h-11 rounded-md border border-slate-200 bg-white px-3 text-sm font-bold text-ink">
                <option>Ordenar por relevancia institucional</option>
                <option>Mayor rotacion</option>
                <option>Stock inmediato</option>
                <option>Precio por volumen</option>
              </select>
            </div>
            <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
              {[...products, ...products].map((product, index) => (
                <ProductCard key={`${product.sku}-${index}`} product={product} />
              ))}
            </div>
          </div>
        </div>
      </section>
      <CtaBand />
    </main>
  );
}
