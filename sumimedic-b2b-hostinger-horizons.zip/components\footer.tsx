import Link from "next/link";
import { Building2, Mail, MapPin, Phone, ShieldCheck } from "lucide-react";
import { navItems } from "@/lib/data";

export function Footer() {
  return (
    <footer className="bg-ink text-white">
      <div className="container-premium grid gap-10 py-14 lg:grid-cols-[1.3fr_.8fr_.8fr_1fr]">
        <div>
          <div className="mb-5 flex items-center gap-3">
            <span className="grid h-11 w-11 place-items-center rounded-md bg-white text-ink">
              <ShieldCheck size={23} />
            </span>
            <div>
              <p className="font-[var(--font-manrope)] text-xl font-extrabold">SUMIMEDIC</p>
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-cyan-200">Distribucion medica B2B</p>
            </div>
          </div>
          <p className="max-w-sm text-sm leading-7 text-slate-300">
            Plataforma corporativa para abastecimiento medico, compras recurrentes,
            licitaciones, cotizaciones empresariales y operacion comercial nacional.
          </p>
        </div>

        <div>
          <h3 className="mb-4 text-sm font-extrabold uppercase tracking-[0.18em] text-cyan-200">Navegacion</h3>
          <div className="grid gap-3 text-sm text-slate-300">
            {navItems.map((item) => (
              <Link key={item.href} href={item.href} className="hover:text-white">
                {item.label}
              </Link>
            ))}
          </div>
        </div>

        <div>
          <h3 className="mb-4 text-sm font-extrabold uppercase tracking-[0.18em] text-cyan-200">B2B</h3>
          <div className="grid gap-3 text-sm text-slate-300">
            <span>Hospitales</span>
            <span>Gobierno</span>
            <span>Clinicas</span>
            <span>Laboratorios</span>
            <span>Distribuidores</span>
          </div>
        </div>

        <div>
          <h3 className="mb-4 text-sm font-extrabold uppercase tracking-[0.18em] text-cyan-200">Contacto comercial</h3>
          <div className="grid gap-4 text-sm text-slate-300">
            <span className="flex gap-3"><Phone size={18} /> +52 55 0000 0000</span>
            <span className="flex gap-3"><Mail size={18} /> ventas@sumimedic.com.mx</span>
            <span className="flex gap-3"><MapPin size={18} /> Cobertura nacional Mexico</span>
            <span className="flex gap-3"><Building2 size={18} /> Atencion institucional y gobierno</span>
          </div>
        </div>
      </div>
      <div className="border-t border-white/10 py-5">
        <div className="container-premium flex flex-col gap-2 text-xs text-slate-400 md:flex-row md:items-center md:justify-between">
          <span>(c) 2026 SUMIMEDIC. Plataforma B2B para distribucion medica.</span>
          <span>SEO tecnico, seguridad, analytics y automatizacion comercial listos para integracion.</span>
        </div>
      </div>
    </footer>
  );
}
