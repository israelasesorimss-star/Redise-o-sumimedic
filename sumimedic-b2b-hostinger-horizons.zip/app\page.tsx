import Link from "next/link";
import {
  ArrowRight,
  ChevronRight,
  DatabaseZap,
  LineChart,
  MessageCircle,
  Network,
  ShieldCheck
} from "lucide-react";
import { MotionReveal } from "@/components/motion-reveal";
import { ProductCard } from "@/components/product-card";
import { SectionHeading } from "@/components/section-heading";
import { CtaBand } from "@/components/cta-band";
import {
  b2bSegments,
  categories,
  certifications,
  executiveMetrics,
  integrations,
  processFlow,
  products,
  trustStats
} from "@/lib/data";

const organizationSchema = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: "SUMIMEDIC",
  url: "https://sumimedic.com.mx",
  description: "Distribuidor B2B de insumos medicos, material hospitalario y equipo clinico en Mexico.",
  areaServed: "MX",
  sameAs: ["https://sumimedic.com.mx"]
};

export default function Home() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationSchema) }}
      />
      <main>
        <section className="relative overflow-hidden bg-radial-depth py-16 md:py-24">
          <div className="absolute inset-0 medical-pattern opacity-70" />
          <div className="container-premium relative grid gap-10 lg:grid-cols-[1.08fr_.92fr] lg:items-center">
            <MotionReveal>
              <div>
                <div className="mb-6 inline-flex items-center gap-2 rounded-md border border-clinical/20 bg-white/75 px-3 py-2 text-xs font-extrabold uppercase tracking-[0.2em] text-clinical shadow-sm">
                  <ShieldCheck size={16} />
                  Distribucion medica B2B nacional
                </div>
                <h1 className="text-balance font-[var(--font-manrope)] text-4xl font-extrabold leading-[1.03] text-ink md:text-6xl">
                  Plataforma premium para compras medicas institucionales.
                </h1>
                <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-600">
                  SUMIMEDIC centraliza catalogo, cotizacion, compras recurrentes,
                  credito empresarial, fichas tecnicas y seguimiento comercial para
                  hospitales, clinicas, laboratorios, gobierno y distribuidores.
                </p>
                <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                  <Link href="/contacto" className="inline-flex h-14 items-center justify-center gap-2 rounded-md bg-ink px-7 text-sm font-extrabold text-white shadow-premium transition hover:bg-clinical">
                    <MessageCircle size={19} />
                    Cotizar con asesor
                  </Link>
                  <Link href="/catalogo" className="inline-flex h-14 items-center justify-center gap-2 rounded-md border border-slate-300 bg-white/80 px-7 text-sm font-extrabold text-ink transition hover:border-clinical hover:text-clinical">
                    Explorar catalogo
                    <ArrowRight size={19} />
                  </Link>
                </div>
              </div>
            </MotionReveal>

            <MotionReveal delay={0.15}>
              <div className="glass-panel clip-dashboard rounded-md p-5 md:p-7">
                <div className="mb-5 flex items-center justify-between">
                  <div>
                    <p className="text-xs font-extrabold uppercase tracking-[0.2em] text-clinical">Executive commerce</p>
                    <h2 className="mt-2 font-[var(--font-manrope)] text-2xl font-extrabold">Pipeline SUMIMEDIC</h2>
                  </div>
                  <span className="rounded-md bg-pulse/10 px-3 py-2 text-xs font-extrabold text-pulse">Live B2B</span>
                </div>
                <div className="grid gap-3 sm:grid-cols-2">
                  {executiveMetrics.map((metric) => {
                    const Icon = metric.icon;
                    return (
                      <div key={metric.label} className="rounded-md border border-slate-200 bg-white p-4">
                        <Icon className="mb-4 text-clinical" size={22} />
                        <p className="text-3xl font-extrabold text-ink">{metric.value}</p>
                        <p className="mt-1 text-sm font-semibold text-slate-500">{metric.label}</p>
                      </div>
                    );
                  })}
                </div>
                <div className="mt-4 rounded-md border border-slate-200 bg-ink p-5 text-white">
                  <div className="mb-4 flex items-center justify-between text-sm">
                    <span className="font-bold">Flujo comercial</span>
                    <LineChart size={18} />
                  </div>
                  <div className="flex items-end gap-2">
                    {[38, 62, 48, 74, 58, 86, 92].map((height, index) => (
                      <span
                        key={index}
                        className="w-full rounded-sm bg-gradient-to-t from-clinical to-pulse"
                        style={{ height }}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </MotionReveal>
          </div>
        </section>

        <section className="border-y border-slate-200 bg-white py-6">
          <div className="container-premium grid gap-4 md:grid-cols-4">
            {trustStats.map((stat) => (
              <div key={stat.label} className="rounded-md border border-slate-100 bg-slate-50 px-5 py-4">
                <p className="text-2xl font-extrabold text-ink">{stat.value}</p>
                <p className="text-sm font-semibold text-slate-500">{stat.label}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="bg-white py-20">
          <div className="container-premium grid gap-10 lg:grid-cols-[.95fr_1.05fr] lg:items-center">
            <SectionHeading
              eyebrow="Supply Chain as a Service"
              title="Abastecimiento medico sin interrupciones."
              text="SUMIMEDIC amplia disponibilidad mediante una red nacional de proveedores certificados, manteniendo control de cotizacion, documentacion, tracking, SLA y recompra."
            />
            <div className="grid gap-4 md:grid-cols-3">
              {[
                { icon: Network, title: "Red certificada", text: "Proveedores auditados por categoria, zona y cumplimiento." },
                { icon: DatabaseZap, title: "Inventario ampliado", text: "Consulta de stock propio y aliado antes de prometer." },
                { icon: ShieldCheck, title: "Control SUMIMEDIC", text: "Aprobacion interna, cotizacion formal y trazabilidad." }
              ].map((item) => {
                const Icon = item.icon;
                return (
                  <article key={item.title} className="rounded-md border border-slate-200 bg-slate-50 p-5">
                    <Icon className="text-clinical" size={26} />
                    <h3 className="mt-4 text-lg font-extrabold text-ink">{item.title}</h3>
                    <p className="mt-2 text-sm leading-7 text-slate-600">{item.text}</p>
                  </article>
                );
              })}
              <div className="md:col-span-3">
                <Link href="/dropshipping-medico-controlado" className="inline-flex h-14 w-full items-center justify-center gap-2 rounded-md bg-ink px-6 text-sm font-extrabold text-white transition hover:bg-clinical md:w-auto">
                  Dropshipping Medico Controlado
                  <ArrowRight size={18} />
                </Link>
              </div>
            </div>
          </div>
        </section>

        <section className="bg-white py-20">
          <div className="container-premium">
            <SectionHeading
              eyebrow="Catalogo corporativo"
              title="Categorias construidas para compras institucionales."
              text="El catalogo no opera como tienda minorista: prioriza trazabilidad, volumen, compatibilidad, documentacion y condiciones por tipo de cliente."
            />
            <div className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
              {categories.map((category) => {
                const Icon = category.icon;
                return (
                  <MotionReveal key={category.name}>
                    <article className="h-full rounded-md border border-slate-200 bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-premium">
                      <Icon className="text-clinical" size={30} />
                      <h3 className="mt-5 font-[var(--font-manrope)] text-xl font-extrabold text-ink">{category.name}</h3>
                      <p className="mt-3 text-sm leading-7 text-slate-600">{category.description}</p>
                      <p className="mt-5 text-sm font-extrabold text-trust">{category.skus}</p>
                    </article>
                  </MotionReveal>
                );
              })}
            </div>
          </div>
        </section>

        <section className="bg-sterile py-20">
          <div className="container-premium">
            <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
              <SectionHeading
                eyebrow="Productos destacados"
                title="SKUs, equipos y consumibles con enfoque B2B."
                text="Cada ficha esta preparada para PDF tecnico, compatibilidades, cotizacion, comparacion y recomendacion cruzada."
              />
              <Link href="/catalogo" className="inline-flex h-12 items-center gap-2 rounded-md border border-slate-300 bg-white px-5 text-sm font-extrabold text-ink">
                Catalogo completo
                <ChevronRight size={18} />
              </Link>
            </div>
            <div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              {products.map((product) => (
                <ProductCard key={product.sku} product={product} />
              ))}
            </div>
          </div>
        </section>

        <section className="bg-white py-20">
          <div className="container-premium grid gap-10 lg:grid-cols-[.9fr_1.1fr] lg:items-start">
            <SectionHeading
              eyebrow="Area B2B"
              title="Venta de relaciones comerciales, no solo productos."
              text="El sistema acompana todo el ciclo comercial: atraccion, cotizacion, CRM, venta, recompra y escalamiento por cuenta."
            />
            <div className="grid gap-4 md:grid-cols-2">
              {b2bSegments.map((segment) => {
                const Icon = segment.icon;
                return (
                  <article key={segment.title} className="rounded-md border border-slate-200 bg-white p-6 shadow-sm">
                    <Icon className="text-clinical" size={26} />
                    <h3 className="mt-4 text-lg font-extrabold text-ink">{segment.title}</h3>
                    <p className="mt-2 text-sm leading-7 text-slate-600">{segment.text}</p>
                  </article>
                );
              })}
            </div>
          </div>
        </section>

        <section className="bg-ink py-20 text-white">
          <div className="container-premium">
            <SectionHeading
              eyebrow="Arquitectura comercial"
              title="Atraccion, conversion, CRM, seguimiento, venta y recompra."
              text="La plataforma esta pensada para operar como motor de ventas institucional, conectada a Ads, analytics, ERP, inventario y automatizaciones."
              align="center"
              tone="dark"
            />
            <div className="mt-12 grid gap-4 md:grid-cols-5">
              {processFlow.map((step, index) => (
                <div key={step.title} className="rounded-md border border-white/10 bg-white/10 p-5">
                  <span className="grid h-9 w-9 place-items-center rounded-md bg-cyan-300 text-sm font-extrabold text-ink">
                    {index + 1}
                  </span>
                  <h3 className="mt-5 font-[var(--font-manrope)] text-lg font-extrabold">{step.title}</h3>
                  <p className="mt-3 text-sm leading-7 text-slate-300">{step.text}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="bg-white py-20">
          <div className="container-premium">
            <SectionHeading
              eyebrow="Confianza institucional"
              title="Senales de seguridad para compras de alto valor."
              text="La experiencia comunica respaldo operativo, transparencia documental, soporte especializado y capacidad nacional."
              align="center"
            />
            <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {certifications.map((item) => {
                const Icon = item.icon;
                return (
                  <div key={item.label} className="flex items-center gap-4 rounded-md border border-slate-200 bg-slate-50 p-5">
                    <span className="grid h-12 w-12 shrink-0 place-items-center rounded-md bg-white text-clinical shadow-sm">
                      <Icon size={23} />
                    </span>
                    <p className="font-bold text-ink">{item.label}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        <section className="bg-sterile py-20">
          <div className="container-premium grid gap-10 lg:grid-cols-[.9fr_1.1fr] lg:items-center">
            <SectionHeading
              eyebrow="Integraciones obligatorias"
              title="Comercio, marketing, operacion, seguridad y analitica."
              text="Preparada para WooCommerce headless o API propia, pagos, credito empresarial, WhatsApp, CRM, ERP, dashboards y medicion avanzada."
            />
            <div className="flex flex-wrap gap-3">
              {integrations.map((integration) => (
                <span key={integration} className="rounded-md border border-slate-200 bg-white px-4 py-3 text-sm font-extrabold text-slate-700 shadow-sm">
                  {integration}
                </span>
              ))}
            </div>
          </div>
        </section>

        <CtaBand />
      </main>
    </>
  );
}
