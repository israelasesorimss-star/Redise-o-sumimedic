import {
  Activity,
  BadgeCheck,
  BarChart3,
  Building2,
  ClipboardCheck,
  DatabaseZap,
  Factory,
  FileText,
  FlaskConical,
  HeartPulse,
  Landmark,
  MapPinned,
  PackageCheck,
  Radar,
  Route,
  ShieldCheck,
  Stethoscope,
  Truck,
  Users,
  Warehouse
} from "lucide-react";

export const navItems = [
  { href: "/", label: "Home" },
  { href: "/catalogo", label: "Catalogo" },
  { href: "/b2b", label: "Area B2B" },
  { href: "/nosotros", label: "Nosotros" },
  { href: "/blog", label: "Blog" },
  { href: "/contacto", label: "Contacto" }
];

export const solutionItems = [
  { href: "/b2b", label: "Abastecimiento Institucional" },
  { href: "/dropshipping-medico-controlado", label: "Dropshipping Medico Controlado" },
  { href: "/b2b#compras-recurrentes", label: "Compras Recurrentes" },
  { href: "/b2b#licitaciones", label: "Licitaciones" },
  { href: "/b2b#convenios", label: "Convenios Empresariales" },
  { href: "/b2b#clientes-corporativos", label: "Clientes Corporativos" }
];

export const categories = [
  {
    name: "Insumos medicos",
    description: "Consumibles de alta rotacion para hospitales, clinicas y consultorios.",
    icon: PackageCheck,
    skus: "8,400+ SKUs"
  },
  {
    name: "Material hospitalario",
    description: "Soluciones para quirofano, urgencias, enfermeria y piso hospitalario.",
    icon: HeartPulse,
    skus: "3,200+ SKUs"
  },
  {
    name: "Equipo clinico",
    description: "Equipamiento medico, diagnostico, monitoreo y mobiliario especializado.",
    icon: Activity,
    skus: "760+ equipos"
  },
  {
    name: "Laboratorio",
    description: "Reactivos, consumibles, toma de muestra y soluciones de control.",
    icon: FlaskConical,
    skus: "1,900+ SKUs"
  }
];

export const products = [
  {
    sku: "SM-GUA-NIT-001",
    name: "Guante de nitrilo grado medico",
    category: "Insumos medicos",
    segment: "Hospitales y gobierno",
    price: "Desde $128 MXN / caja",
    badges: ["Compra recurrente", "Volumen", "Ficha tecnica"],
    stock: "Inventario nacional",
    extendedAvailability: "Disponible mediante red de proveedores certificados",
    image: "https://images.unsplash.com/photo-1583947215259-38e31be8751f?auto=format&fit=crop&w=900&q=80"
  },
  {
    sku: "SM-MON-VS-220",
    name: "Monitor de signos vitales multiparametro",
    category: "Equipo clinico",
    segment: "Clinicas y hospitales",
    price: "Cotizacion especializada",
    badges: ["Instalacion", "Garantia", "Capacitacion"],
    stock: "Entrega programada",
    extendedAvailability: "Surtido controlado con proveedor autorizado y SLA validado",
    image: "https://images.unsplash.com/photo-1583912267550-d44c719cdf8d?auto=format&fit=crop&w=900&q=80"
  },
  {
    sku: "SM-JER-EST-010",
    name: "Jeringa esteril desechable",
    category: "Material hospitalario",
    segment: "Compras masivas",
    price: "Precio escalonado",
    badges: ["Alto consumo", "Mayoreo", "Contrato"],
    stock: "Stock permanente",
    extendedAvailability: "Abastecimiento ampliado para volumen institucional",
    image: "https://images.unsplash.com/photo-1603398938378-e54eab446dde?auto=format&fit=crop&w=900&q=80"
  },
  {
    sku: "SM-LAB-TM-050",
    name: "Tubos para toma de muestra",
    category: "Laboratorio",
    segment: "Laboratorios y gobierno",
    price: "Desde contrato marco",
    badges: ["Compatibilidad", "Licitacion", "PDF"],
    stock: "Cobertura regional",
    extendedAvailability: "Disponible con trazabilidad documental y proveedor certificado",
    image: "https://images.unsplash.com/photo-1579165466741-7f35e4755660?auto=format&fit=crop&w=900&q=80"
  }
];

export const trustStats = [
  { label: "Cobertura operativa", value: "32 estados" },
  { label: "Lineas de producto", value: "14K+" },
  { label: "SLA de cotizacion", value: "< 2 h" },
  { label: "Clientes recurrentes", value: "B2B" }
];

export const b2bSegments = [
  { title: "Hospitales", icon: Building2, text: "Abasto recurrente, catalogos homologados y entregas programadas." },
  { title: "Gobierno", icon: Landmark, text: "Soporte documental, licitaciones, contratos marco y trazabilidad." },
  { title: "Clinicas", icon: Stethoscope, text: "Paquetes por especialidad, credito empresarial y asesoria tecnica." },
  { title: "Laboratorios", icon: FlaskConical, text: "Compatibilidades, consumibles, reactivos y control de inventario." }
];

export const processFlow = [
  { title: "Atraccion", text: "SEO tecnico, Ads, rich snippets y landing pages por categoria." },
  { title: "Conversion", text: "Cotizacion inmediata, WhatsApp API, formularios inteligentes y comparador." },
  { title: "CRM", text: "Lead scoring, pipeline comercial, historial y automatizacion de seguimiento." },
  { title: "Venta", text: "Pedidos, pagos, credito empresarial, facturacion e integracion ERP." },
  { title: "Recompra", text: "Listas recurrentes, alertas de abastecimiento y remarketing por segmento." }
];

export const integrations = [
  "Stripe",
  "Mercado Pago",
  "PayPal",
  "Transferencia",
  "Credito empresarial",
  "WhatsApp Business API",
  "Google Merchant",
  "Google Ads",
  "Meta Ads",
  "GA4",
  "Search Console",
  "ERP",
  "CRM",
  "Hotjar",
  "Clarity"
];

export const certifications = [
  { icon: ShieldCheck, label: "Compras seguras y trazables" },
  { icon: ClipboardCheck, label: "Documentacion para auditoria" },
  { icon: BadgeCheck, label: "Proveedores verificados" },
  { icon: FileText, label: "Fichas tecnicas descargables" },
  { icon: Truck, label: "Distribucion nacional" },
  { icon: Factory, label: "Escalabilidad operativa" }
];

export const blogPosts = [
  {
    slug: "guia-compras-hospitalarias-b2b",
    title: "Guia para optimizar compras hospitalarias B2B",
    excerpt: "Como reducir quiebres de inventario, homologar SKUs y automatizar recompra institucional.",
    tag: "Compras hospitalarias"
  },
  {
    slug: "licitaciones-insumos-medicos-mexico",
    title: "Checklist documental para licitaciones de insumos medicos",
    excerpt: "Elementos clave para participar con trazabilidad, fichas tecnicas y cumplimiento operativo.",
    tag: "Licitaciones"
  },
  {
    slug: "control-inventario-clinicas",
    title: "Modelo de inventario recurrente para clinicas privadas",
    excerpt: "Pronostico de consumo, minimos operativos y alertas comerciales conectadas al CRM.",
    tag: "Automatizacion"
  }
];

export const executiveMetrics = [
  { label: "Leads calificados", value: "248", icon: Users },
  { label: "Cotizaciones activas", value: "86", icon: FileText },
  { label: "Pedidos recurrentes", value: "42", icon: PackageCheck },
  { label: "Pipeline estimado", value: "$4.8M", icon: BarChart3 }
];

export const supplyChainFlow = [
  { title: "Solicitud cliente", text: "El comprador institucional solicita compra, cotizacion, volumen o abastecimiento recurrente." },
  { title: "Inventario local", text: "SUMIMEDIC valida stock propio, prioridades de surtido, minimos y promesas disponibles." },
  { title: "Proveedor autorizado", text: "Si no hay stock, se consulta disponibilidad con proveedores auditados por categoria y zona." },
  { title: "Aprobacion SUMIMEDIC", text: "La operacion se aprueba internamente antes de presentar cotizacion formal al cliente." },
  { title: "Surtido controlado", text: "El proveedor surte bajo control SUMIMEDIC, con SLA, tracking, incidencias y evidencia." },
  { title: "CRM y recompra", text: "El historial alimenta alertas de reposicion, seguimiento ejecutivo y recompra automatizada." }
];

export const supplierControls = [
  { icon: ClipboardCheck, title: "Validacion documental", text: "Alta controlada con expediente, certificados, cumplimiento sanitario y trazabilidad legal." },
  { icon: ShieldCheck, title: "Cumplimiento regulatorio", text: "Productos con ficha tecnica, garantia, certificados y documentacion descargable." },
  { icon: Truck, title: "SLA logistico", text: "Tiempos por zona, historial de cumplimiento, incidencias y validacion de entrega." },
  { icon: Radar, title: "Score de confiabilidad", text: "Calificacion interna por disponibilidad, cumplimiento, calidad documental y entregas." },
  { icon: MapPinned, title: "Cobertura por zona", text: "Asignacion por region, categoria, capacidad de surtido y especializacion medica." },
  { icon: Factory, title: "Control administrativo", text: "Proveedores no auditados quedan fuera del flujo comercial y operativo." }
];

export const inventoryControls = [
  { icon: Warehouse, title: "Inventario propio", text: "Prioridad de surtido desde SUMIMEDIC con alertas de stock minimo." },
  { icon: DatabaseZap, title: "Inventario aliado", text: "Disponibilidad sincronizada con proveedores certificados antes de cotizar." },
  { icon: Route, title: "Prioridades de surtido", text: "Reglas para evitar sobreventa, promesas falsas y tiempos no aprobados." }
];

export const trackingStages = [
  { status: "Validacion", owner: "SUMIMEDIC", eta: "15 min", detail: "Revision de stock, documentos y proveedor posible." },
  { status: "Confirmacion", owner: "Proveedor certificado", eta: "45 min", detail: "Disponibilidad, lote, cobertura y SLA de entrega." },
  { status: "Aprobacion", owner: "Control operativo", eta: "30 min", detail: "Cotizacion formal y condiciones B2B autorizadas." },
  { status: "Surtido", owner: "Red autorizada", eta: "24-72 h", detail: "Tracking, incidencia, evidencia y validacion de entrega." }
];
