"use client";

import Link from "next/link";
import { ChevronDown, Menu, MessageCircle, Search, ShieldCheck, X } from "lucide-react";
import { useState } from "react";
import { navItems, solutionItems } from "@/lib/data";

export function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-slate-200/70 bg-white/86 backdrop-blur-xl">
      <div className="container-premium flex h-20 items-center justify-between gap-5">
        <Link href="/" className="flex items-center gap-3" aria-label="SUMIMEDIC inicio">
          <span className="grid h-11 w-11 place-items-center rounded-md bg-ink text-white shadow-glow">
            <ShieldCheck size={24} />
          </span>
          <span>
            <span className="block font-[var(--font-manrope)] text-xl font-extrabold tracking-wide text-ink">
              SUMIMEDIC
            </span>
            <span className="block text-xs font-semibold uppercase tracking-[0.22em] text-clinical">
              Medical B2B Supply
            </span>
          </span>
        </Link>

        <nav className="hidden items-center gap-7 text-sm font-semibold text-slate-700 lg:flex">
          {navItems.map((item) => (
            <Link key={item.href} href={item.href} className="transition hover:text-clinical">
              {item.label}
            </Link>
          ))}
          <div className="group relative">
            <button className="inline-flex items-center gap-1 transition hover:text-clinical">
              Soluciones B2B
              <ChevronDown size={16} />
            </button>
            <div className="invisible absolute left-1/2 top-9 w-72 -translate-x-1/2 rounded-md border border-slate-200 bg-white p-2 opacity-0 shadow-premium transition group-hover:visible group-hover:opacity-100">
              {solutionItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="block rounded-md px-3 py-3 text-sm font-bold text-slate-700 hover:bg-slate-50 hover:text-clinical"
                >
                  {item.label}
                </Link>
              ))}
            </div>
          </div>
        </nav>

        <div className="hidden items-center gap-2 lg:flex">
          <button className="grid h-11 w-11 place-items-center rounded-md border border-slate-200 bg-white text-slate-700 transition hover:border-clinical hover:text-clinical" aria-label="Buscar">
            <Search size={19} />
          </button>
          <Link
            href="/contacto"
            className="inline-flex h-11 items-center gap-2 rounded-md bg-ink px-5 text-sm font-bold text-white shadow-premium transition hover:bg-clinical"
          >
            <MessageCircle size={18} />
            Cotizar ahora
          </Link>
        </div>

        <button
          className="grid h-11 w-11 place-items-center rounded-md border border-slate-200 bg-white lg:hidden"
          onClick={() => setOpen((value) => !value)}
          aria-label="Abrir menu"
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {open && (
        <div className="border-t border-slate-200 bg-white lg:hidden">
          <div className="container-premium grid gap-2 py-4">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="rounded-md px-3 py-3 text-sm font-bold text-slate-700 hover:bg-slate-50"
                onClick={() => setOpen(false)}
              >
                {item.label}
              </Link>
            ))}
            <div className="border-t border-slate-100 pt-2">
              <p className="px-3 py-2 text-xs font-extrabold uppercase tracking-[0.2em] text-clinical">Soluciones B2B</p>
              {solutionItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="block rounded-md px-3 py-3 text-sm font-bold text-slate-700 hover:bg-slate-50"
                  onClick={() => setOpen(false)}
                >
                  {item.label}
                </Link>
              ))}
            </div>
            <Link href="/contacto" className="mt-2 rounded-md bg-ink px-4 py-3 text-center text-sm font-bold text-white">
              Solicitar cotizacion
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
