# SUMIMEDIC B2B Ecommerce Platform

Plataforma web premium para SUMIMEDIC, enfocada en distribucion medica B2B, conversion comercial, SEO tecnico, cotizacion institucional, CRM, recompra e integraciones empresariales.

## Stack

- Next.js App Router
- React
- Tailwind CSS
- Framer Motion
- Lucide Icons
- API route para cotizaciones B2B
- SEO con metadata, sitemap, robots y JSON-LD

## Rutas

- `/` Home institucional y conversion.
- `/catalogo` Catalogo B2B con filtros, busqueda, comparador y fichas.
- `/b2b` Clientes institucionales, gobierno, hospitales, licitaciones y recompra.
- `/dropshipping-medico-controlado` Supply Chain as a Service con proveedores certificados, inventario sincronizado, tracking y control SUMIMEDIC.
- `/nosotros` Historia, cobertura, infraestructura y confianza empresarial.
- `/blog` Contenido SEO para captacion organica.
- `/contacto` Formulario inteligente para CRM y cotizacion.
- `/api/quotes` Endpoint mock para crear leads comerciales.
- `/api/supply-chain` Endpoint mock para solicitudes de abastecimiento medico controlado.

## Ejecutar

```bash
npm install
npm run dev
```

## Produccion

```bash
npm run build
npm run start
```

## Notas de integracion

La arquitectura objetivo esta documentada en `docs/architecture.md`. El siguiente paso natural es conectar catalogo, inventario, precios por cliente, CRM, ERP, pagos y WhatsApp Business API.
