import type { Metadata } from "next";
import { Inter, Manrope } from "next/font/google";
import { GoogleAnalytics } from "@next/third-parties/google";
import "./globals.css";
import { Footer } from "@/components/footer";
import { Header } from "@/components/header";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });
const manrope = Manrope({ subsets: ["latin"], variable: "--font-manrope" });

export const metadata: Metadata = {
  metadataBase: new URL("https://sumimedic.com.mx"),
  title: {
    default: "SUMIMEDIC | Distribucion B2B de insumos medicos en Mexico",
    template: "%s | SUMIMEDIC"
  },
  description:
    "Plataforma B2B premium para suministro medico, material hospitalario, equipo clinico, consumibles y soluciones para hospitales, clinicas, laboratorios, gobierno y compras recurrentes.",
  keywords: [
    "distribuidor medico",
    "insumos medicos mayoreo",
    "material hospitalario",
    "equipo clinico",
    "proveedor medico gobierno",
    "compras hospitalarias B2B"
  ],
  openGraph: {
    title: "SUMIMEDIC | Distribucion medica B2B nacional",
    description:
      "Catalogo, cotizacion, credito empresarial, compras recurrentes e integraciones comerciales para instituciones de salud.",
    url: "https://sumimedic.com.mx",
    siteName: "SUMIMEDIC",
    locale: "es_MX",
    type: "website"
  },
  alternates: {
    canonical: "/"
  },
  robots: {
    index: true,
    follow: true
  }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es-MX" className={`${inter.variable} ${manrope.variable}`}>
      <body>
        <Header />
        {children}
        <Footer />
        <GoogleAnalytics gaId="G-SUMIMEDIC" />
      </body>
    </html>
  );
}
