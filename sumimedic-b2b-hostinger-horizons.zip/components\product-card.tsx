import Image from "next/image";
import { Download, MessageCircle, Network, Scale, ShieldCheck } from "lucide-react";

type Product = {
  sku: string;
  name: string;
  category: string;
  segment: string;
  price: string;
  badges: string[];
  stock: string;
  extendedAvailability: string;
  image: string;
};

export function ProductCard({ product }: { product: Product }) {
  return (
    <article className="group overflow-hidden rounded-md border border-slate-200 bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-premium">
      <div className="relative h-52 overflow-hidden bg-slate-100">
        <Image
          src={product.image}
          alt={product.name}
          fill
          className="object-cover transition duration-500 group-hover:scale-105"
          sizes="(max-width: 768px) 100vw, 33vw"
        />
        <div className="absolute left-4 top-4 rounded-md bg-white/90 px-3 py-2 text-xs font-extrabold text-clinical shadow-sm">
          {product.category}
        </div>
      </div>
      <div className="p-5">
        <div className="mb-3 flex items-center justify-between gap-3 text-xs font-bold text-slate-500">
          <span>{product.sku}</span>
          <span className="inline-flex items-center gap-1 text-pulse">
            <ShieldCheck size={14} />
            {product.stock}
          </span>
        </div>
        <h3 className="font-[var(--font-manrope)] text-xl font-extrabold leading-snug text-ink">{product.name}</h3>
        <p className="mt-2 text-sm font-semibold text-slate-500">{product.segment}</p>
        <div className="mt-4 flex flex-wrap gap-2">
          {product.badges.map((badge) => (
            <span key={badge} className="rounded-md bg-slate-100 px-2.5 py-1.5 text-xs font-bold text-slate-600">
              {badge}
            </span>
          ))}
        </div>
        <div className="mt-5 border-t border-slate-100 pt-5">
          <div className="mb-4 rounded-md border border-clinical/15 bg-clinical/5 p-3">
            <p className="mb-1 inline-flex items-center gap-2 text-xs font-extrabold uppercase tracking-[0.16em] text-clinical">
              <Network size={15} />
              Disponibilidad Extendida
            </p>
            <p className="text-sm font-semibold leading-6 text-slate-700">{product.extendedAvailability}</p>
            <button className="mt-3 w-full rounded-md bg-white px-3 py-2 text-xs font-extrabold text-ink shadow-sm transition hover:text-clinical">
              Solicitar abastecimiento inmediato
            </button>
          </div>
          <p className="mb-4 text-lg font-extrabold text-ink">{product.price}</p>
          <div className="grid grid-cols-3 gap-2">
            <button className="grid h-11 place-items-center rounded-md bg-ink text-white" aria-label="Solicitar cotizacion">
              <MessageCircle size={18} />
            </button>
            <button className="grid h-11 place-items-center rounded-md border border-slate-200 text-slate-700" aria-label="Comparar producto">
              <Scale size={18} />
            </button>
            <button className="grid h-11 place-items-center rounded-md border border-slate-200 text-slate-700" aria-label="Descargar ficha tecnica">
              <Download size={18} />
            </button>
          </div>
        </div>
      </div>
    </article>
  );
}
