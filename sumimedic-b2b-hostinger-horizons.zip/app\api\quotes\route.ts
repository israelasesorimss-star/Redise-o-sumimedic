import { NextResponse } from "next/server";

export async function POST(request: Request) {
  const body = await request.json();

  return NextResponse.json(
    {
      ok: true,
      leadId: `SUM-${Date.now()}`,
      status: "qualified",
      routing: {
        crm: "pipeline-b2b",
        sla: "2h",
        owner: "asesor-institucional"
      },
      received: body
    },
    { status: 201 }
  );
}
