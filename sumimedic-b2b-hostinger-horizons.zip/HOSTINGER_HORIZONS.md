# SUMIMEDIC B2B Platform - Hostinger Horizons

Proyecto listo para cargar en Hostinger Horizons como aplicacion Next.js.

## Comandos sugeridos

```bash
npm install
npm run build
npm run start
```

## Rutas principales

- `/`
- `/catalogo`
- `/b2b`
- `/dropshipping-medico-controlado`
- `/nosotros`
- `/blog`
- `/contacto`

## Variables e integraciones pendientes

Conectar las credenciales reales de:

- CRM
- ERP
- WhatsApp Business API
- Stripe, Mercado Pago y PayPal
- GA4, Search Console, Meta Pixel, Hotjar o Clarity
- Inventario propio y proveedores certificados

El modulo de Dropshipping Medico Controlado esta estructurado como Supply Chain as a Service con control operativo SUMIMEDIC.
