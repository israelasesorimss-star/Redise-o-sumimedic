import type { Metadata } from "next";
import { Building2, Map, ShieldCheck, Truck, Users, Warehouse } from "lucide-react";
import { CtaBand } from "@/components/cta-band";
import { SectionHeading } from "@/components/section-heading";

export const metadata: Metadata = {
  title: "Nosotros",
  description:
    "Historia, capacidad operativa, infraestructura, cobertura nacional, valores y confianza empresarial de SUMIMEDIC.",
  alternates: { canonical: "/nosotros" }
};

const capabilities = [
  { icon: Warehouse, title: "Infraestructura", text: "Operacion preparada para inventario, almacenamiento, trazabilidad y entregas programadas." },
  { icon: Truck, title: "Cobertura nacional", text: "Abastecimiento para instituciones de salud con coordinacion regional y seguimiento." },
  { icon: Users, title: "Atencion especializada", text: "Asesores por segmento, soporte tecnico y gestion comercial por cuenta." },
  { icon: ShieldCheck, title: "Confianza empresarial", text: "Procesos documentados, fichas tecnicas, roles, permisos y control de auditoria." }
];

export default function NosotrosPage() {
  return (
    <main>
      <section className="bg-radial-depth py-16">
        <div className="container-premium grid gap-10 lg:grid-cols-[1fr_.9fr] lg:items-center">
          <SectionHeading
            eyebrow="Empresa nacional"
            title="SUMIMEDIC proyecta capacidad, orden y respaldo institucional."
            text="La marca se presenta como un socio de abastecimiento medico para organizaciones que necesitan continuidad, cumplimiento y relacion comercial de largo plazo."
          />
          <div className="glass-panel rounded-md p-6">
            <div className="grid gap-4 sm:grid-cols-2">
              {[
                ["14K+", "Productos y soluciones"],
                ["32", "Estados con cobertura"],
                ["B2B", "Modelo comercial"],
                ["CRM", "Seguimiento activo"]
              ].map(([value, label]) => (
                <div key={label} className="rounded-md bg-white p-5">
                  <p className="text-3xl font-extrabold text-ink">{value}</p>
                  <p className="mt-1 text-sm font-bold text-slate-500">{label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="bg-white py-16">
        <div className="container-premium grid gap-10 lg:grid-cols-[.8fr_1.2fr]">
          <div>
            <p className="mb-3 text-xs font-extrabold uppercase tracking-[0.24em] text-clinical">Historia y valores</p>
            <h2 className="font-[var(--font-manrope)] text-3xl font-extrabold leading-tight md:text-5xl">
              Servicio medico con mentalidad enterprise.
            </h2>
          </div>
          <div className="grid gap-5 text-base leading-8 text-slate-600">
            <p>
              SUMIMEDIC atiende compras de insumos, consumibles, material hospitalario y equipo clinico con enfoque en continuidad operativa. La plataforma digital fortalece la relacion con clientes institucionales al unir catalogo, cotizacion, CRM, analitica y recompra.
            </p>
            <p>
              El diseno evita la logica de marketplace generico y presenta una empresa seria: categorias homologadas, documentacion tecnica, indicadores comerciales, cobertura nacional y procesos preparados para gobierno, hospitales, clinicas y laboratorios.
            </p>
          </div>
        </div>
      </section>

      <section className="bg-sterile py-16">
        <div className="container-premium">
          <SectionHeading eyebrow="Capacidad operativa" title="Infraestructura para crecer con cuentas complejas." align="center" />
          <div className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
            {capabilities.map((item) => {
              const Icon = item.icon;
              return (
                <article key={item.title} className="rounded-md border border-slate-200 bg-white p-6 shadow-sm">
                  <Icon className="text-clinical" size={30} />
                  <h3 className="mt-5 text-lg font-extrabold">{item.title}</h3>
                  <p className="mt-3 text-sm leading-7 text-slate-600">{item.text}</p>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      <section className="bg-ink py-16 text-white">
        <div className="container-premium grid gap-8 lg:grid-cols-[1fr_1fr] lg:items-center">
          <div>
            <div className="mb-5 inline-flex items-center gap-2 rounded-md bg-white/10 px-3 py-2 text-xs font-extrabold uppercase tracking-[0.18em] text-cyan-100">
              <Map size={16} />
              Cobertura nacional
            </div>
            <h2 className="font-[var(--font-manrope)] text-3xl font-extrabold md:text-5xl">Distribucion preparada para Mexico.</h2>
            <p className="mt-5 text-base leading-8 text-slate-300">
              La operacion puede conectarse a ERP, rutas, inventario, pedidos recurrentes y dashboards por region.
            </p>
          </div>
          <div className="rounded-md border border-white/10 bg-white/10 p-6">
            <Building2 className="mb-5 text-cyan-200" size={34} />
            <p className="text-2xl font-extrabold">Hospitales, clinicas, laboratorios, distribuidores y gobierno.</p>
            <p className="mt-4 text-sm leading-7 text-slate-300">
              Una sola plataforma para compradores, asesores, administradores, gerencia comercial y direccion.
            </p>
          </div>
        </div>
      </section>
      <CtaBand />
    </main>
  );
}
