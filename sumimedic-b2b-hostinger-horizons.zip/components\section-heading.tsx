export function SectionHeading({
  eyebrow,
  title,
  text,
  align = "left",
  tone = "light"
}: {
  eyebrow: string;
  title: string;
  text?: string;
  align?: "left" | "center";
  tone?: "light" | "dark";
}) {
  return (
    <div className={align === "center" ? "mx-auto max-w-3xl text-center" : "max-w-3xl"}>
      <p className={`mb-3 text-xs font-extrabold uppercase tracking-[0.24em] ${tone === "dark" ? "text-cyan-200" : "text-clinical"}`}>
        {eyebrow}
      </p>
      <h2 className={`font-[var(--font-manrope)] text-3xl font-extrabold leading-tight md:text-5xl ${tone === "dark" ? "text-white" : "text-ink"}`}>
        {title}
      </h2>
      {text && <p className={`mt-5 text-base leading-8 md:text-lg ${tone === "dark" ? "text-slate-300" : "text-slate-600"}`}>{text}</p>}
    </div>
  );
}
