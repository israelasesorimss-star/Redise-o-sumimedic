import type { MetadataRoute } from "next";

const baseUrl = "https://sumimedic.com.mx";

export default function sitemap(): MetadataRoute.Sitemap {
  const routes = ["", "/catalogo", "/b2b", "/dropshipping-medico-controlado", "/nosotros", "/blog", "/contacto"];

  return routes.map((route) => ({
    url: `${baseUrl}${route}`,
    lastModified: new Date(),
    changeFrequency: route === "" || route === "/catalogo" ? "daily" : "weekly",
    priority: route === "" ? 1 : 0.8
  }));
}
