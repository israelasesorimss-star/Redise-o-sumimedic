import Link from "next/link";
import { ArrowRight, MessageCircle, ShieldCheck } from "lucide-react";

export function CtaBand() {
  return (
    <section className="bg-white py-16">
      <div className="container-premium overflow-hidden rounded-md bg-ink p-8 text-white shadow-premium md:p-12">
        <div className="grid gap-8 lg:grid-cols-[1.2fr_.8fr] lg:items-center">
          <div>
            <div className="mb-5 inline-flex items-center gap-2 rounded-md border border-white/15 bg-white/10 px-3 py-2 text-xs font-bold uppercase tracking-[0.18em] text-cyan-100">
              <ShieldCheck size={16} />
              Cotizacion institucional
            </div>
            <h2 className="font-[var(--font-manrope)] text-3xl font-extrabold leading-tight md:text-5xl">
              Active un flujo comercial B2B en menos de 2 horas.
            </h2>
            <p className="mt-5 max-w-2xl text-base leading-8 text-slate-300">
              Reciba listas recurrentes, precios escalonados, soporte documental,
              compatibilidades y seguimiento por asesor especializado.
            </p>
          </div>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-1">
            <Link href="/contacto" className="inline-flex h-14 items-center justify-center gap-2 rounded-md bg-white px-6 text-sm font-extrabold text-ink transition hover:bg-cyan-50">
              <MessageCircle size={19} />
              Solicitar cotizacion
            </Link>
            <Link href="/catalogo" className="inline-flex h-14 items-center justify-center gap-2 rounded-md border border-white/20 px-6 text-sm font-extrabold text-white transition hover:bg-white/10">
              Ver catalogo B2B
              <ArrowRight size={19} />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
