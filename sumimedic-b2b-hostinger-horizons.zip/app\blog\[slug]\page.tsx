import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft, CheckCircle2 } from "lucide-react";
import { blogPosts } from "@/lib/data";

type Props = {
  params: { slug: string };
};

export function generateStaticParams() {
  return blogPosts.map((post) => ({ slug: post.slug }));
}

export function generateMetadata({ params }: Props): Metadata {
  const post = blogPosts.find((item) => item.slug === params.slug);

  return {
    title: post?.title ?? "Articulo SEO medico B2B",
    description: post?.excerpt ?? "Contenido SEO para compradores institucionales de insumos medicos.",
    alternates: { canonical: `/blog/${params.slug}` }
  };
}

export default function BlogPostPage({ params }: Props) {
  const post = blogPosts.find((item) => item.slug === params.slug) ?? blogPosts[0];

  return (
    <main>
      <article className="bg-white py-16">
        <div className="container-premium max-w-4xl">
          <Link href="/blog" className="mb-8 inline-flex items-center gap-2 text-sm font-extrabold text-clinical">
            <ArrowLeft size={17} />
            Volver al blog
          </Link>
          <span className="rounded-md bg-clinical/10 px-3 py-2 text-xs font-extrabold text-clinical">{post.tag}</span>
          <h1 className="mt-6 font-[var(--font-manrope)] text-4xl font-extrabold leading-tight text-ink md:text-6xl">
            {post.title}
          </h1>
          <p className="mt-6 text-lg leading-8 text-slate-600">{post.excerpt}</p>

          <div className="mt-10 max-w-none text-base leading-8 text-slate-600">
            <p>
              Este contenido funciona como base SEO para capturar compradores
              institucionales y dirigirlos hacia cotizacion, CRM y recompra. La
              estructura editorial debe ampliarse con datos, tablas, preguntas
              frecuentes y enlaces internos al catalogo.
            </p>
          </div>

          <div className="mt-10 grid gap-4 md:grid-cols-3">
            {["Intencion de busqueda", "CTA de cotizacion", "Schema FAQ"].map((item) => (
              <div key={item} className="rounded-md border border-slate-200 bg-slate-50 p-5">
                <CheckCircle2 className="text-pulse" size={24} />
                <p className="mt-4 font-extrabold text-ink">{item}</p>
              </div>
            ))}
          </div>
        </div>
      </article>
    </main>
  );
}
