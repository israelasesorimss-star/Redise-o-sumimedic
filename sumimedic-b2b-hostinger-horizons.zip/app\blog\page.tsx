import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, BookOpen, SearchCheck } from "lucide-react";
import { SectionHeading } from "@/components/section-heading";
import { blogPosts } from "@/lib/data";

export const metadata: Metadata = {
  title: "Blog SEO medico B2B",
  description:
    "Contenido SEO sobre compras medicas, guias hospitalarias, licitaciones, tendencias del sector salud y automatizacion comercial.",
  alternates: { canonical: "/blog" }
};

export default function BlogPage() {
  return (
    <main>
      <section className="bg-radial-depth py-16">
        <div className="container-premium">
          <SectionHeading
            eyebrow="SEO dominante"
            title="Contenido medico para atraer compradores institucionales."
            text="La estrategia editorial apunta a keywords transaccionales e informacionales: insumos medicos mayoreo, licitaciones, compras hospitalarias, fichas tecnicas y automatizacion."
            align="center"
          />
        </div>
      </section>

      <section className="bg-white py-16">
        <div className="container-premium grid gap-6 md:grid-cols-3">
          {blogPosts.map((post) => (
            <article key={post.slug} className="rounded-md border border-slate-200 bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-premium">
              <div className="mb-5 flex items-center justify-between">
                <span className="rounded-md bg-clinical/10 px-3 py-2 text-xs font-extrabold text-clinical">{post.tag}</span>
                <BookOpen size={20} className="text-slate-400" />
              </div>
              <h2 className="font-[var(--font-manrope)] text-2xl font-extrabold leading-tight">{post.title}</h2>
              <p className="mt-4 text-sm leading-7 text-slate-600">{post.excerpt}</p>
              <Link href={`/blog/${post.slug}`} className="mt-6 inline-flex items-center gap-2 text-sm font-extrabold text-clinical">
                Leer estrategia
                <ArrowRight size={17} />
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className="bg-ink py-16 text-white">
        <div className="container-premium grid gap-8 lg:grid-cols-[.8fr_1.2fr] lg:items-center">
          <div>
            <SearchCheck size={36} className="mb-5 text-cyan-200" />
            <h2 className="font-[var(--font-manrope)] text-3xl font-extrabold md:text-5xl">SEO tecnico listo para escalar.</h2>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            {["Schema markup", "Rich snippets", "Sitemap dinamico", "Canonicals", "Meta por categoria", "Core Web Vitals", "Search Console", "Landing pages Ads"].map((item) => (
              <span key={item} className="rounded-md border border-white/10 bg-white/10 px-4 py-3 text-sm font-bold">
                {item}
              </span>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}
