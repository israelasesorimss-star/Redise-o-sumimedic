import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./lib/**/*.{js,ts,jsx,tsx,mdx}"
  ],
  theme: {
    extend: {
      colors: {
        graphite: "#111827",
        ink: "#172033",
        clinical: "#0E7490",
        trust: "#2563EB",
        sterile: "#F6FAFD",
        pulse: "#10B981",
        platinum: "#D7DEE8"
      },
      boxShadow: {
        premium: "0 24px 80px rgba(15, 23, 42, 0.14)",
        glow: "0 0 60px rgba(14, 116, 144, 0.20)"
      },
      backgroundImage: {
        "medical-grid":
          "linear-gradient(rgba(14,116,144,.08) 1px, transparent 1px), linear-gradient(90deg, rgba(14,116,144,.08) 1px, transparent 1px)",
        "radial-depth":
          "radial-gradient(circle at 16% 18%, rgba(16,185,129,.18), transparent 28%), radial-gradient(circle at 82% 14%, rgba(37,99,235,.16), transparent 25%), linear-gradient(135deg, #f8fbff 0%, #eef7fb 54%, #ffffff 100%)"
      }
    }
  },
  plugins: []
};

export default config;
