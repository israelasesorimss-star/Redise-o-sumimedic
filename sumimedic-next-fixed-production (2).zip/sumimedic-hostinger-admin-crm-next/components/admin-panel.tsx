"use client";

import {
  Activity,
  BadgeCheck,
  BarChart3,
  CheckCircle2,
  ClipboardCheck,
  Database,
  FileText,
  Image as ImageIcon,
  LockKeyhole,
  LogIn,
  PackagePlus,
  RefreshCw,
  Save,
  ShieldCheck,
  Truck,
  Upload,
  UserCog,
  Zap
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import {
  AdminIntegration,
  AdminProduct,
  AdminQuote,
  AdminSupplier,
  CrmAccount,
  initialAdminIntegrations,
  initialAdminProducts,
  initialAdminQuotes,
  initialAdminSuppliers,
  initialCrmAccounts
} from "@/lib/admin-data";

type Tab = "resumen" | "productos" | "crm" | "proveedores" | "cotizaciones" | "integraciones" | "contenido";
type AdminRole = "Administrador" | "Gerente Comercial" | "Operaciones" | "Marketing";

const storageKey = "sumimedic-admin-state";
const sessionKey = "sumimedic-admin-session";

function statusClass(status: string) {
  if (["Activo", "Certificado", "Conectado", "Ganada", "Cliente", "Recompra"].includes(status)) {
    return "bg-pulse/10 text-pulse";
  }

  if (["Revision", "Validacion", "Cotizada", "Calificado", "Cotizacion", "Negociacion"].includes(status)) {
    return "bg-amber-100 text-amber-700";
  }

  return "bg-slate-100 text-slate-600";
}

export function AdminPanel() {
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [adminUser, setAdminUser] = useState("admin@sumimedic.com.mx");
  const [adminCode, setAdminCode] = useState("");
  const [adminRole, setAdminRole] = useState<AdminRole>("Administrador");
  const [activeTab, setActiveTab] = useState<Tab>("resumen");
  const [products, setProducts] = useState<AdminProduct[]>(initialAdminProducts);
  const [suppliers, setSuppliers] = useState<AdminSupplier[]>(initialAdminSuppliers);
  const [quotes, setQuotes] = useState<AdminQuote[]>(initialAdminQuotes);
  const [integrations, setIntegrations] = useState<AdminIntegration[]>(initialAdminIntegrations);
  const [crmAccounts, setCrmAccounts] = useState<CrmAccount[]>(initialCrmAccounts);
  const [message, setMessage] = useState("Panel cargado con datos iniciales SUMIMEDIC.");
  const [bulkProducts, setBulkProducts] = useState("SM-CAT-001,Cubrebocas tricapa,Insumos medicos,5000,1000,$85 / caja\nSM-EQP-330,Bascula clinica digital,Equipo clinico,15,5,Cotizacion");
  const [newProduct, setNewProduct] = useState({
    sku: "",
    name: "",
    category: "Insumos medicos",
    stock: "0",
    minStock: "0",
    price: "Cotizacion"
  });

  useEffect(() => {
    const session = window.localStorage.getItem(sessionKey);
    if (session) {
      try {
        const parsedSession = JSON.parse(session);
        setIsAuthorized(Boolean(parsedSession.isAuthorized));
        setAdminUser(parsedSession.user ?? "admin@sumimedic.com.mx");
        setAdminRole(parsedSession.role ?? "Administrador");
      } catch {
        setIsAuthorized(false);
      }
    }

    const rawState = window.localStorage.getItem(storageKey);

    if (!rawState) return;

    try {
      const parsed = JSON.parse(rawState);
      setProducts(parsed.products ?? initialAdminProducts);
      setSuppliers(parsed.suppliers ?? initialAdminSuppliers);
      setQuotes(parsed.quotes ?? initialAdminQuotes);
      setIntegrations(parsed.integrations ?? initialAdminIntegrations);
      setCrmAccounts(parsed.crmAccounts ?? initialCrmAccounts);
      setMessage("Datos administrativos restaurados desde este navegador.");
    } catch {
      setMessage("No se pudo restaurar el estado local. Se cargaron datos base.");
    }
  }, []);

  useEffect(() => {
    window.localStorage.setItem(
      storageKey,
      JSON.stringify({
        products,
        suppliers,
        quotes,
        integrations,
        crmAccounts
      })
    );
  }, [products, suppliers, quotes, integrations, crmAccounts]);

  const dashboard = useMemo(() => {
    const lowStock = products.filter((product) => product.stock <= product.minStock).length;
    const certifiedSuppliers = suppliers.filter((supplier) => supplier.status === "Certificado").length;
    const activeQuotes = quotes.filter((quote) => quote.status !== "Ganada").length;
    const connectedIntegrations = integrations.filter((integration) => integration.status === "Conectado").length;
    const crmPipeline = crmAccounts.filter((account) => account.stage !== "Cliente").length;

    return [
      { label: "Productos activos", value: products.length, icon: Database },
      { label: "Alertas de stock", value: lowStock, icon: Activity },
      { label: "Proveedores certificados", value: certifiedSuppliers, icon: ShieldCheck },
      { label: "Cotizaciones abiertas", value: activeQuotes, icon: FileText },
      { label: "Cuentas CRM", value: crmPipeline, icon: UserCog },
      { label: "Integraciones conectadas", value: connectedIntegrations, icon: Zap }
    ];
  }, [products, suppliers, quotes, integrations, crmAccounts]);

  function addProduct() {
    if (!newProduct.sku.trim() || !newProduct.name.trim()) {
      setMessage("Completa SKU y nombre antes de guardar el producto.");
      return;
    }

    const product: AdminProduct = {
      sku: newProduct.sku.trim(),
      name: newProduct.name.trim(),
      category: newProduct.category,
      stock: Number(newProduct.stock) || 0,
      minStock: Number(newProduct.minStock) || 0,
      price: newProduct.price,
      status: "Revision",
      documents: ["Ficha tecnica pendiente", "Certificado pendiente"],
      supplier: "Pendiente de asignacion",
      image: ""
    };

    setProducts((current) => [product, ...current]);
    setNewProduct({ sku: "", name: "", category: "Insumos medicos", stock: "0", minStock: "0", price: "Cotizacion" });
    setMessage(`Producto ${product.sku} agregado en estado Revision.`);
  }

  function importBulkProducts() {
    const rows = bulkProducts
      .split("\n")
      .map((row) => row.trim())
      .filter(Boolean);

    const parsedProducts = rows.map((row) => {
      const [sku, name, category, stock, minStock, price] = row.split(",").map((cell) => cell.trim());

      return {
        sku,
        name,
        category: category || "Insumos medicos",
        stock: Number(stock) || 0,
        minStock: Number(minStock) || 0,
        price: price || "Cotizacion",
        status: "Revision" as const,
        documents: ["Ficha tecnica pendiente", "Certificado pendiente"],
        supplier: "Carga masiva",
        image: ""
      };
    }).filter((product) => product.sku && product.name);

    if (!parsedProducts.length) {
      setMessage("No se detectaron productos validos para carga masiva.");
      return;
    }

    setProducts((current) => [...parsedProducts, ...current]);
    setMessage(`${parsedProducts.length} productos importados por carga masiva.`);
  }

  function uploadProductImage(sku: string, file?: File) {
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      setProducts((current) =>
        current.map((product) =>
          product.sku === sku
            ? {
                ...product,
                image: String(reader.result)
              }
            : product
        )
      );
      setMessage(`Imagen cargada para producto ${sku}.`);
    };
    reader.readAsDataURL(file);
  }

  function syncInventory() {
    setProducts((current) =>
      current.map((product) => ({
        ...product,
        stock: product.stock <= product.minStock ? product.stock + 250 : product.stock + 25,
        status: "Activo"
      }))
    );
    setMessage("Inventario sincronizado: se actualizaron existencias propias y aliadas.");
  }

  function approveSupplier(id: string) {
    setSuppliers((current) =>
      current.map((supplier) =>
        supplier.id === id
          ? {
              ...supplier,
              score: Math.max(supplier.score, 88),
              status: "Certificado"
            }
          : supplier
      )
    );
    setMessage(`Proveedor ${id} certificado y habilitado para red controlada.`);
  }

  function advanceQuote(id: string) {
    const order: AdminQuote["status"][] = ["Nueva", "Validacion", "Cotizada", "Ganada"];

    setQuotes((current) =>
      current.map((quote) => {
        if (quote.id !== id) return quote;
        const nextStatus = order[Math.min(order.indexOf(quote.status) + 1, order.length - 1)];
        return { ...quote, status: nextStatus };
      })
    );
    setMessage(`Cotizacion ${id} movida al siguiente paso comercial.`);
  }

  function toggleIntegration(key: string) {
    setIntegrations((current) =>
      current.map((integration) =>
        integration.key === key
          ? {
              ...integration,
              status: integration.status === "Conectado" ? "Revision" : "Conectado"
            }
          : integration
      )
    );
    setMessage("Estado de integracion actualizado. Para produccion agrega la variable ENV correspondiente.");
  }

  function advanceCrmAccount(id: string) {
    const order: CrmAccount["stage"][] = ["Lead", "Calificado", "Cotizacion", "Negociacion", "Cliente", "Recompra"];

    setCrmAccounts((current) =>
      current.map((account) => {
        if (account.id !== id) return account;
        const nextStage = order[Math.min(order.indexOf(account.stage) + 1, order.length - 1)];
        return {
          ...account,
          stage: nextStage,
          lastTouch: "Ahora",
          nextAction: nextStage === "Recompra" ? "Programar compra recurrente" : "Continuar seguimiento comercial"
        };
      })
    );
    setMessage(`Cuenta ${id} avanzada dentro del CRM comercial.`);
  }

  function loginAdmin() {
    if (adminCode !== "SUMIMEDIC-ADMIN") {
      setMessage("Codigo incorrecto. Usa el codigo temporal de administrador asignado.");
      return;
    }

    const session = {
      isAuthorized: true,
      user: adminUser,
      role: adminRole
    };

    window.localStorage.setItem(sessionKey, JSON.stringify(session));
    setIsAuthorized(true);
    setMessage(`Acceso autorizado para ${adminUser} con rol ${adminRole}.`);
  }

  function logoutAdmin() {
    window.localStorage.removeItem(sessionKey);
    setIsAuthorized(false);
    setAdminCode("");
    setMessage("Sesion administrativa cerrada.");
  }

  function exportState() {
    const payload = JSON.stringify({ products, suppliers, quotes, integrations, crmAccounts }, null, 2);
    const blob = new Blob([payload], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "sumimedic-admin-export.json";
    link.click();
    URL.revokeObjectURL(url);
    setMessage("Exportacion JSON generada para respaldo o migracion.");
  }

  const tabs: { id: Tab; label: string }[] = [
    { id: "resumen", label: "Resumen" },
    { id: "productos", label: "Productos" },
    { id: "crm", label: "CRM" },
    { id: "proveedores", label: "Proveedores" },
    { id: "cotizaciones", label: "Cotizaciones" },
    { id: "integraciones", label: "Integraciones" },
    { id: "contenido", label: "Contenido" }
  ];

  if (!isAuthorized) {
    return (
      <div className="bg-radial-depth py-16">
        <div className="container-premium grid gap-8 lg:grid-cols-[.95fr_1.05fr] lg:items-center">
          <div>
            <div className="mb-6 inline-flex items-center gap-2 rounded-md border border-clinical/20 bg-white/80 px-3 py-2 text-xs font-extrabold uppercase tracking-[0.2em] text-clinical shadow-sm">
              <LockKeyhole size={16} />
              Acceso privado
            </div>
            <h1 className="font-[var(--font-manrope)] text-4xl font-extrabold leading-tight text-ink md:text-6xl">
              Panel exclusivo para administrador y roles autorizados.
            </h1>
            <p className="mt-5 max-w-2xl text-base leading-8 text-slate-600">
              Esta compuerta es temporal para demostracion. En produccion debe conectarse a Supabase Auth, Auth0, Clerk o al sistema de usuarios que elijas, con roles, permisos, auditoria y politicas por modulo.
            </p>
          </div>

          <section className="rounded-md border border-slate-200 bg-white p-6 shadow-premium">
            <h2 className="font-[var(--font-manrope)] text-2xl font-extrabold text-ink">Iniciar sesion administrativa</h2>
            <p className="mt-2 text-sm leading-7 text-slate-600">
              Codigo temporal de prueba: <strong>SUMIMEDIC-ADMIN</strong>
            </p>
            <div className="mt-5 grid gap-3">
              <input value={adminUser} onChange={(event) => setAdminUser(event.target.value)} className="h-12 rounded-md border border-slate-200 px-4 text-sm font-bold outline-none focus:border-clinical" placeholder="Correo autorizado" />
              <select value={adminRole} onChange={(event) => setAdminRole(event.target.value as AdminRole)} className="h-12 rounded-md border border-slate-200 px-4 text-sm font-bold outline-none focus:border-clinical">
                <option>Administrador</option>
                <option>Gerente Comercial</option>
                <option>Operaciones</option>
                <option>Marketing</option>
              </select>
              <input value={adminCode} onChange={(event) => setAdminCode(event.target.value)} className="h-12 rounded-md border border-slate-200 px-4 text-sm font-bold outline-none focus:border-clinical" placeholder="Codigo de acceso" type="password" />
              <button onClick={loginAdmin} className="inline-flex h-12 items-center justify-center gap-2 rounded-md bg-ink px-5 text-sm font-extrabold text-white">
                <LogIn size={18} />
                Entrar al panel
              </button>
            </div>
            <div className="mt-5 rounded-md bg-slate-50 p-4 text-sm leading-7 text-slate-600">
              Recomendacion: no publiques `/admin` como enlace principal cuando conectes autenticacion real. Usa URL privada, middleware y proteccion por rol.
            </div>
          </section>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-sterile py-10">
      <div className="container-premium">
        <div className="mb-6 rounded-md border border-slate-200 bg-white p-5 shadow-sm">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <p className="text-xs font-extrabold uppercase tracking-[0.22em] text-clinical">Panel Administrativo</p>
              <h1 className="mt-2 font-[var(--font-manrope)] text-3xl font-extrabold text-ink md:text-5xl">
                Control operativo SUMIMEDIC
              </h1>
              <p className="mt-3 max-w-3xl text-sm leading-7 text-slate-600">
                Modulo para administrar productos, proveedores certificados, cotizaciones, contenido e integraciones. Esta version funciona en cliente y guarda cambios en el navegador hasta conectar una base de datos real.
              </p>
            </div>
            <div className="grid gap-2 sm:grid-cols-2">
              <div className="rounded-md border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-bold text-slate-600">
                {adminUser}
                <span className="block text-xs font-extrabold uppercase tracking-[0.16em] text-clinical">{adminRole}</span>
              </div>
              <div className="grid gap-2">
                <button onClick={exportState} className="inline-flex h-12 items-center justify-center gap-2 rounded-md bg-ink px-5 text-sm font-extrabold text-white">
                  <Save size={18} />
                  Exportar datos
                </button>
                <button onClick={logoutAdmin} className="inline-flex h-10 items-center justify-center rounded-md border border-slate-200 px-4 text-xs font-extrabold text-ink">
                  Cerrar sesion
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="mb-6 flex gap-2 overflow-x-auto rounded-md border border-slate-200 bg-white p-2">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`h-11 shrink-0 rounded-md px-4 text-sm font-extrabold transition ${
                activeTab === tab.id ? "bg-ink text-white" : "text-slate-600 hover:bg-slate-50"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="mb-6 rounded-md border border-clinical/20 bg-white p-4 text-sm font-bold text-slate-700">
          {message}
        </div>

        {activeTab === "resumen" && (
          <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-5">
            {dashboard.map((metric) => {
              const Icon = metric.icon;
              return (
                <article key={metric.label} className="rounded-md border border-slate-200 bg-white p-5 shadow-sm">
                  <Icon className="text-clinical" size={26} />
                  <p className="mt-5 text-3xl font-extrabold text-ink">{metric.value}</p>
                  <p className="mt-1 text-sm font-bold text-slate-500">{metric.label}</p>
                </article>
              );
            })}
          </div>
        )}

        {activeTab === "productos" && (
          <div className="grid gap-6 xl:grid-cols-[.85fr_1.15fr]">
            <section className="rounded-md border border-slate-200 bg-white p-5 shadow-sm">
              <h2 className="font-[var(--font-manrope)] text-2xl font-extrabold">Alta de producto</h2>
              <div className="mt-5 grid gap-3">
                <input value={newProduct.sku} onChange={(event) => setNewProduct({ ...newProduct, sku: event.target.value })} className="h-12 rounded-md border border-slate-200 px-4 text-sm font-bold outline-none focus:border-clinical" placeholder="SKU" />
                <input value={newProduct.name} onChange={(event) => setNewProduct({ ...newProduct, name: event.target.value })} className="h-12 rounded-md border border-slate-200 px-4 text-sm font-bold outline-none focus:border-clinical" placeholder="Nombre del producto" />
                <select value={newProduct.category} onChange={(event) => setNewProduct({ ...newProduct, category: event.target.value })} className="h-12 rounded-md border border-slate-200 px-4 text-sm font-bold outline-none focus:border-clinical">
                  <option>Insumos medicos</option>
                  <option>Material hospitalario</option>
                  <option>Equipo clinico</option>
                  <option>Laboratorio</option>
                </select>
                <div className="grid gap-3 sm:grid-cols-2">
                  <input value={newProduct.stock} onChange={(event) => setNewProduct({ ...newProduct, stock: event.target.value })} className="h-12 rounded-md border border-slate-200 px-4 text-sm font-bold outline-none focus:border-clinical" placeholder="Stock" type="number" />
                  <input value={newProduct.minStock} onChange={(event) => setNewProduct({ ...newProduct, minStock: event.target.value })} className="h-12 rounded-md border border-slate-200 px-4 text-sm font-bold outline-none focus:border-clinical" placeholder="Stock minimo" type="number" />
                </div>
                <input value={newProduct.price} onChange={(event) => setNewProduct({ ...newProduct, price: event.target.value })} className="h-12 rounded-md border border-slate-200 px-4 text-sm font-bold outline-none focus:border-clinical" placeholder="Precio o politica comercial" />
                <button onClick={addProduct} className="inline-flex h-12 items-center justify-center gap-2 rounded-md bg-ink px-5 text-sm font-extrabold text-white">
                  <PackagePlus size={18} />
                  Guardar producto
                </button>
              </div>

              <div className="mt-6 border-t border-slate-100 pt-6">
                <h3 className="inline-flex items-center gap-2 font-[var(--font-manrope)] text-xl font-extrabold">
                  <Upload size={20} />
                  Carga masiva CSV
                </h3>
                <p className="mt-2 text-sm leading-7 text-slate-600">
                  Formato por linea: SKU, nombre, categoria, stock, stock minimo, precio.
                </p>
                <textarea
                  value={bulkProducts}
                  onChange={(event) => setBulkProducts(event.target.value)}
                  className="mt-3 min-h-36 w-full rounded-md border border-slate-200 p-4 text-sm font-semibold outline-none focus:border-clinical"
                />
                <button onClick={importBulkProducts} className="mt-3 inline-flex h-11 w-full items-center justify-center gap-2 rounded-md border border-slate-200 px-4 text-sm font-extrabold text-ink">
                  <Upload size={17} />
                  Importar productos
                </button>
              </div>
            </section>

            <section className="rounded-md border border-slate-200 bg-white p-5 shadow-sm">
              <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <h2 className="font-[var(--font-manrope)] text-2xl font-extrabold">Inventario y documentos</h2>
                <button onClick={syncInventory} className="inline-flex h-11 items-center justify-center gap-2 rounded-md border border-slate-200 px-4 text-sm font-extrabold text-ink">
                  <RefreshCw size={17} />
                  Sincronizar
                </button>
              </div>
              <div className="grid gap-3">
                {products.map((product) => (
                  <article key={product.sku} className="rounded-md border border-slate-200 bg-slate-50 p-4">
                    <div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
                      <div>
                        <p className="text-xs font-extrabold uppercase tracking-[0.16em] text-clinical">{product.sku}</p>
                        <h3 className="mt-1 text-lg font-extrabold text-ink">{product.name}</h3>
                        <p className="mt-1 text-sm font-semibold text-slate-500">{product.category} | {product.supplier}</p>
                        <p className="mt-2 text-sm font-bold text-slate-600">Stock {product.stock} / minimo {product.minStock}</p>
                      </div>
                      {product.image ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={product.image} alt={product.name} className="h-20 w-20 rounded-md object-cover" />
                      ) : (
                        <span className="grid h-20 w-20 place-items-center rounded-md bg-white text-slate-400">
                          <ImageIcon size={24} />
                        </span>
                      )}
                      <span className={`rounded-md px-3 py-2 text-xs font-extrabold ${statusClass(product.status)}`}>{product.status}</span>
                    </div>
                    <div className="mt-3 flex flex-wrap gap-2">
                      {product.documents.map((document) => (
                        <span key={document} className="rounded-md bg-white px-2.5 py-1.5 text-xs font-bold text-slate-600">{document}</span>
                      ))}
                    </div>
                    <label className="mt-4 inline-flex h-10 cursor-pointer items-center justify-center gap-2 rounded-md border border-slate-200 bg-white px-4 text-xs font-extrabold text-ink">
                      <ImageIcon size={16} />
                      Cargar imagen
                      <input type="file" accept="image/*" className="hidden" onChange={(event) => uploadProductImage(product.sku, event.target.files?.[0])} />
                    </label>
                  </article>
                ))}
              </div>
            </section>
          </div>
        )}

        {activeTab === "crm" && (
          <div className="grid gap-6 xl:grid-cols-[.8fr_1.2fr]">
            <section className="rounded-md border border-slate-200 bg-ink p-6 text-white shadow-premium">
              <p className="text-xs font-extrabold uppercase tracking-[0.2em] text-cyan-200">CRM SUMIMEDIC</p>
              <h2 className="mt-3 font-[var(--font-manrope)] text-3xl font-extrabold">Pipeline comercial B2B</h2>
              <p className="mt-4 text-sm leading-7 text-slate-300">
                CRM visual para seguimiento de hospitales, clinicas, laboratorios, gobierno y distribuidores. Preparado para conectarse a HubSpot, Zoho, Odoo, Salesforce, Monday CRM o un backend propio.
              </p>
              <div className="mt-6 grid gap-3 sm:grid-cols-2">
                {[
                  ["Pipeline activo", crmAccounts.length],
                  ["Prioridad alta", crmAccounts.filter((account) => account.priority === "Alta").length],
                  ["En negociacion", crmAccounts.filter((account) => account.stage === "Negociacion").length],
                  ["Recompra", crmAccounts.filter((account) => account.stage === "Recompra").length]
                ].map(([label, value]) => (
                  <div key={label} className="rounded-md border border-white/10 bg-white/10 p-4">
                    <p className="text-3xl font-extrabold">{value}</p>
                    <p className="mt-1 text-sm font-bold text-slate-300">{label}</p>
                  </div>
                ))}
              </div>
            </section>

            <section className="rounded-md border border-slate-200 bg-white p-5 shadow-sm">
              <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <h2 className="font-[var(--font-manrope)] text-2xl font-extrabold">Cuentas y oportunidades</h2>
                  <p className="mt-1 text-sm font-semibold text-slate-500">Avanza cuentas, programa acciones y mide recurrencia.</p>
                </div>
                <button onClick={() => setMessage("CRM listo para conectar mediante CRM_API_KEY y webhooks comerciales.")} className="inline-flex h-11 items-center justify-center rounded-md border border-slate-200 px-4 text-sm font-extrabold text-ink">
                  Preparar integracion
                </button>
              </div>
              <div className="grid gap-3">
                {crmAccounts.map((account) => (
                  <article key={account.id} className="rounded-md border border-slate-200 bg-slate-50 p-4">
                    <div className="grid gap-4 lg:grid-cols-[1fr_auto_auto] lg:items-center">
                      <div>
                        <p className="text-xs font-extrabold uppercase tracking-[0.16em] text-clinical">{account.id} | {account.segment}</p>
                        <h3 className="mt-1 text-lg font-extrabold text-ink">{account.name}</h3>
                        <p className="mt-1 text-sm font-bold text-slate-500">{account.contact}</p>
                        <p className="mt-2 text-sm leading-6 text-slate-600">{account.nextAction}</p>
                      </div>
                      <div>
                        <p className="text-xl font-extrabold text-ink">{account.value}</p>
                        <p className="mt-1 text-xs font-bold text-slate-500">Ultimo contacto: {account.lastTouch}</p>
                        <span className={`mt-2 inline-block rounded-md px-3 py-2 text-xs font-extrabold ${account.priority === "Alta" ? "bg-rose-100 text-rose-700" : "bg-slate-100 text-slate-600"}`}>
                          Prioridad {account.priority}
                        </span>
                      </div>
                      <div className="grid gap-2">
                        <span className={`rounded-md px-3 py-2 text-center text-xs font-extrabold ${statusClass(account.stage)}`}>{account.stage}</span>
                        <button onClick={() => advanceCrmAccount(account.id)} className="inline-flex h-10 items-center justify-center rounded-md bg-ink px-4 text-xs font-extrabold text-white">
                          Avanzar CRM
                        </button>
                      </div>
                    </div>
                  </article>
                ))}
              </div>
            </section>
          </div>
        )}

        {activeTab === "proveedores" && (
          <div className="grid gap-4 lg:grid-cols-3">
            {suppliers.map((supplier) => (
              <article key={supplier.id} className="rounded-md border border-slate-200 bg-white p-5 shadow-sm">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="text-xs font-extrabold uppercase tracking-[0.16em] text-clinical">{supplier.id}</p>
                    <h2 className="mt-2 text-xl font-extrabold text-ink">{supplier.name}</h2>
                  </div>
                  <span className={`rounded-md px-3 py-2 text-xs font-extrabold ${statusClass(supplier.status)}`}>{supplier.status}</span>
                </div>
                <p className="mt-4 text-sm font-bold text-slate-500">{supplier.category} | {supplier.coverage}</p>
                <p className="mt-2 text-sm font-bold text-slate-600">Score {supplier.score}/100 | SLA {supplier.sla}</p>
                <div className="mt-4 flex flex-wrap gap-2">
                  {supplier.documents.map((document) => (
                    <span key={document} className="rounded-md bg-slate-100 px-2.5 py-1.5 text-xs font-bold text-slate-600">{document}</span>
                  ))}
                </div>
                <button onClick={() => approveSupplier(supplier.id)} className="mt-5 inline-flex h-11 w-full items-center justify-center gap-2 rounded-md bg-ink px-4 text-sm font-extrabold text-white">
                  <BadgeCheck size={17} />
                  Certificar proveedor
                </button>
              </article>
            ))}
          </div>
        )}

        {activeTab === "cotizaciones" && (
          <div className="rounded-md border border-slate-200 bg-white p-5 shadow-sm">
            <h2 className="mb-5 font-[var(--font-manrope)] text-2xl font-extrabold">Pipeline comercial</h2>
            <div className="grid gap-3">
              {quotes.map((quote) => (
                <article key={quote.id} className="grid gap-4 rounded-md border border-slate-200 bg-slate-50 p-4 lg:grid-cols-[1fr_auto_auto] lg:items-center">
                  <div>
                    <p className="text-xs font-extrabold uppercase tracking-[0.16em] text-clinical">{quote.id} | {quote.segment}</p>
                    <h3 className="mt-1 text-lg font-extrabold text-ink">{quote.client}</h3>
                    <p className="text-sm font-bold text-slate-500">{quote.owner}</p>
                  </div>
                  <div>
                    <p className="text-xl font-extrabold text-ink">{quote.amount}</p>
                    <span className={`mt-2 inline-block rounded-md px-3 py-2 text-xs font-extrabold ${statusClass(quote.status)}`}>{quote.status}</span>
                  </div>
                  <button onClick={() => advanceQuote(quote.id)} className="inline-flex h-11 items-center justify-center gap-2 rounded-md bg-ink px-4 text-sm font-extrabold text-white">
                    <CheckCircle2 size={17} />
                    Avanzar
                  </button>
                </article>
              ))}
            </div>
          </div>
        )}

        {activeTab === "integraciones" && (
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            {integrations.map((integration) => (
              <article key={integration.key} className="rounded-md border border-slate-200 bg-white p-5 shadow-sm">
                <ClipboardCheck className="text-clinical" size={26} />
                <h2 className="mt-4 text-lg font-extrabold text-ink">{integration.name}</h2>
                <p className="mt-1 text-sm font-bold text-slate-500">{integration.type}</p>
                <p className="mt-3 rounded-md bg-slate-50 p-3 text-xs font-bold text-slate-600">{integration.envKey}</p>
                <span className={`mt-3 inline-block rounded-md px-3 py-2 text-xs font-extrabold ${statusClass(integration.status)}`}>{integration.status}</span>
                <button onClick={() => toggleIntegration(integration.key)} className="mt-5 inline-flex h-11 w-full items-center justify-center rounded-md border border-slate-200 px-4 text-sm font-extrabold text-ink">
                  Cambiar estado
                </button>
              </article>
            ))}
          </div>
        )}

        {activeTab === "contenido" && (
          <div className="grid gap-5 lg:grid-cols-3">
            {[
              ["Home", "Hero, CTAs, categorias, productos destacados y confianza institucional."],
              ["Catalogo", "Filtros, disponibilidad extendida, fichas tecnicas y solicitud de abastecimiento."],
              ["Blog SEO", "Guias hospitalarias, licitaciones, tendencias y automatizacion comercial."],
              ["B2B", "Clientes institucionales, gobierno, compras recurrentes y convenios."],
              ["Dropshipping Controlado", "Supply Chain as a Service, proveedores certificados, SLA y tracking."],
              ["Contacto", "Formulario inteligente conectado a CRM y atencion especializada."]
            ].map(([title, text]) => (
              <article key={title} className="rounded-md border border-slate-200 bg-white p-5 shadow-sm">
                <BarChart3 className="text-clinical" size={25} />
                <h2 className="mt-4 text-lg font-extrabold text-ink">{title}</h2>
                <p className="mt-2 text-sm leading-7 text-slate-600">{text}</p>
                <button onClick={() => setMessage(`Modulo ${title} listo para conectar a CMS.`)} className="mt-4 inline-flex h-10 items-center justify-center rounded-md border border-slate-200 px-4 text-sm font-extrabold text-ink">
                  Preparar edicion CMS
                </button>
              </article>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
