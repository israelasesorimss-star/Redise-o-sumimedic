export type AdminProduct = {
  sku: string;
  name: string;
  category: string;
  stock: number;
  minStock: number;
  price: string;
  status: "Activo" | "Revision" | "Pausado";
  documents: string[];
  supplier: string;
  image?: string;
};

export type AdminSupplier = {
  id: string;
  name: string;
  category: string;
  coverage: string;
  score: number;
  sla: string;
  status: "Certificado" | "Revision" | "Bloqueado";
  documents: string[];
};

export type AdminQuote = {
  id: string;
  client: string;
  segment: string;
  amount: string;
  status: "Nueva" | "Validacion" | "Cotizada" | "Ganada";
  owner: string;
};

export type AdminIntegration = {
  key: string;
  name: string;
  type: string;
  status: "Pendiente" | "Conectado" | "Revision";
  envKey: string;
};

export type CrmAccount = {
  id: string;
  name: string;
  segment: "Hospital" | "Clinica" | "Laboratorio" | "Gobierno" | "Distribuidor";
  contact: string;
  stage: "Lead" | "Calificado" | "Cotizacion" | "Negociacion" | "Cliente" | "Recompra";
  value: string;
  nextAction: string;
  priority: "Alta" | "Media" | "Baja";
  lastTouch: string;
};

export const initialAdminProducts: AdminProduct[] = [
  {
    sku: "SM-GUA-NIT-001",
    name: "Guante de nitrilo grado medico",
    category: "Insumos medicos",
    stock: 1240,
    minStock: 500,
    price: "$128 / caja",
    status: "Activo",
    documents: ["Ficha tecnica", "Certificado sanitario", "Garantia"],
    supplier: "SUMIMEDIC Central",
    image: ""
  },
  {
    sku: "SM-MON-VS-220",
    name: "Monitor de signos vitales multiparametro",
    category: "Equipo clinico",
    stock: 8,
    minStock: 12,
    price: "Cotizacion",
    status: "Revision",
    documents: ["Ficha tecnica", "Garantia", "Manual"],
    supplier: "Proveedor Biomedico Norte",
    image: ""
  },
  {
    sku: "SM-LAB-TM-050",
    name: "Tubos para toma de muestra",
    category: "Laboratorio",
    stock: 3200,
    minStock: 1000,
    price: "Contrato marco",
    status: "Activo",
    documents: ["Ficha tecnica", "Compatibilidades", "Certificado"],
    supplier: "Red Laboratorio Bajio",
    image: ""
  }
];

export const initialAdminSuppliers: AdminSupplier[] = [
  {
    id: "PROV-001",
    name: "Proveedor Biomedico Norte",
    category: "Equipo clinico",
    coverage: "Norte y Bajio",
    score: 94,
    sla: "48-72 h",
    status: "Certificado",
    documents: ["Expediente legal", "Certificados", "SLA firmado"]
  },
  {
    id: "PROV-002",
    name: "Red Laboratorio Bajio",
    category: "Laboratorio",
    coverage: "Centro, Bajio",
    score: 91,
    sla: "24-48 h",
    status: "Certificado",
    documents: ["Cumplimiento sanitario", "Ficha fiscal", "Trazabilidad"]
  },
  {
    id: "PROV-003",
    name: "Consumibles Sureste",
    category: "Material hospitalario",
    coverage: "Sureste",
    score: 78,
    sla: "72 h",
    status: "Revision",
    documents: ["Expediente pendiente", "SLA pendiente"]
  }
];

export const initialAdminQuotes: AdminQuote[] = [
  {
    id: "COT-2481",
    client: "Hospital Regional Delta",
    segment: "Hospital",
    amount: "$186,400",
    status: "Validacion",
    owner: "Asesor institucional"
  },
  {
    id: "COT-2482",
    client: "Laboratorio Clinico Norte",
    segment: "Laboratorio",
    amount: "$74,900",
    status: "Nueva",
    owner: "Ejecutivo B2B"
  },
  {
    id: "COT-2483",
    client: "Gobierno Municipal Salud",
    segment: "Gobierno",
    amount: "$1,250,000",
    status: "Cotizada",
    owner: "Licitaciones"
  }
];

export const initialAdminIntegrations: AdminIntegration[] = [
  { key: "stripe", name: "Stripe", type: "Pagos", status: "Pendiente", envKey: "STRIPE_SECRET_KEY" },
  { key: "mercadopago", name: "Mercado Pago", type: "Pagos", status: "Pendiente", envKey: "MERCADO_PAGO_ACCESS_TOKEN" },
  { key: "paypal", name: "PayPal", type: "Pagos", status: "Pendiente", envKey: "PAYPAL_CLIENT_SECRET" },
  { key: "whatsapp", name: "WhatsApp Business API", type: "Operacion", status: "Pendiente", envKey: "WHATSAPP_TOKEN" },
  { key: "ga4", name: "Google Analytics GA4", type: "Analytics", status: "Conectado", envKey: "NEXT_PUBLIC_GA_ID" },
  { key: "crm", name: "CRM Comercial", type: "Ventas", status: "Revision", envKey: "CRM_API_KEY" },
  { key: "erp", name: "ERP Inventario", type: "Operacion", status: "Pendiente", envKey: "ERP_API_KEY" },
  { key: "meta", name: "Meta Pixel", type: "Marketing", status: "Pendiente", envKey: "NEXT_PUBLIC_META_PIXEL_ID" }
];

export const initialCrmAccounts: CrmAccount[] = [
  {
    id: "CRM-001",
    name: "Hospital Regional Delta",
    segment: "Hospital",
    contact: "compras@hospitaldelta.mx",
    stage: "Cotizacion",
    value: "$186,400",
    nextAction: "Enviar cotizacion formal y fichas tecnicas",
    priority: "Alta",
    lastTouch: "Hoy"
  },
  {
    id: "CRM-002",
    name: "Laboratorio Clinico Norte",
    segment: "Laboratorio",
    contact: "direccion@labnorte.mx",
    stage: "Calificado",
    value: "$74,900",
    nextAction: "Confirmar volumen mensual y recurrencia",
    priority: "Media",
    lastTouch: "Ayer"
  },
  {
    id: "CRM-003",
    name: "Gobierno Municipal Salud",
    segment: "Gobierno",
    contact: "licitaciones@saludmunicipal.gob.mx",
    stage: "Negociacion",
    value: "$1,250,000",
    nextAction: "Validar expediente documental y SLA",
    priority: "Alta",
    lastTouch: "Hace 2 dias"
  },
  {
    id: "CRM-004",
    name: "Clinica Especialidades Roma",
    segment: "Clinica",
    contact: "admin@clinicaroma.mx",
    stage: "Recompra",
    value: "$42,300",
    nextAction: "Programar reposicion automatica",
    priority: "Media",
    lastTouch: "Hace 4 dias"
  }
];
