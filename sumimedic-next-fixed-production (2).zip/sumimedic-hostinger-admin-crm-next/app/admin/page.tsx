import type { Metadata } from "next";
import { AdminPanel } from "@/components/admin-panel";

export const metadata: Metadata = {
  title: "Panel Administrativo",
  description:
    "Panel administrativo SUMIMEDIC para productos, proveedores certificados, inventario, cotizaciones, integraciones, CRM y contenido B2B.",
  alternates: { canonical: "/admin" },
  robots: {
    index: false,
    follow: false
  }
};

export default function AdminPage() {
  return <AdminPanel />;
}
