import type { Metadata } from "next";
import Link from "next/link";
import {
  ArrowRight,
  BadgeCheck,
  ClipboardList,
  FileCheck2,
  LockKeyhole,
  MapPinned,
  MessageCircle,
  Network,
  Radar,
  ShieldCheck,
  Truck
} from "lucide-react";
import { CtaBand } from "@/components/cta-band";
import { SectionHeading } from "@/components/section-heading";
import { inventoryControls, supplierControls, supplyChainFlow, trackingStages } from "@/lib/data";

export const metadata: Metadata = {
  title: "Dropshipping Medico Controlado",
  description:
    "Modulo de Supply Chain as a Service para abastecimiento medico B2B con proveedores certificados, trazabilidad, cumplimiento documental, tracking y control SUMIMEDIC.",
  alternates: { canonical: "/dropshipping-medico-controlado" }
};

const serviceSchema = {
  "@context": "https://schema.org",
  "@type": "Service",
  name: "Dropshipping Medico Controlado SUMIMEDIC",
  provider: {
    "@type": "Organization",
    name: "SUMIMEDIC",
    url: "https://sumimedic.com.mx"
  },
  serviceType: "Supply Chain as a Service para abastecimiento medico B2B",
  areaServed: "MX"
};

export default function DropshippingMedicoControladoPage() {
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(serviceSchema) }} />
      <main>
        <section className="relative overflow-hidden bg-radial-depth py-16 md:py-24">
          <div className="absolute inset-0 medical-pattern opacity-70" />
          <div className="container-premium relative grid gap-10 lg:grid-cols-[1.05fr_.95fr] lg:items-center">
            <div>
              <div className="mb-6 inline-flex items-center gap-2 rounded-md border border-clinical/20 bg-white/80 px-3 py-2 text-xs font-extrabold uppercase tracking-[0.2em] text-clinical shadow-sm">
                <Network size={16} />
                Supply Chain as a Service
              </div>
              <h1 className="text-balance font-[var(--font-manrope)] text-4xl font-extrabold leading-[1.03] text-ink md:text-6xl">
                Dropshipping medico controlado para abastecimiento institucional.
              </h1>
              <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-600">
                SUMIMEDIC amplia disponibilidad mediante proveedores certificados
                sin ceder el control comercial, documental, logistico ni la
                experiencia del cliente. No es marketplace abierto: es suministro
                medico inteligente bajo gobierno operativo.
              </p>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <Link href="/contacto" className="inline-flex h-14 items-center justify-center gap-2 rounded-md bg-ink px-7 text-sm font-extrabold text-white shadow-premium transition hover:bg-clinical">
                  <MessageCircle size={19} />
                  Solicitar abastecimiento
                </Link>
                <Link href="/catalogo" className="inline-flex h-14 items-center justify-center gap-2 rounded-md border border-slate-300 bg-white/80 px-7 text-sm font-extrabold text-ink transition hover:border-clinical hover:text-clinical">
                  Ver productos con disponibilidad extendida
                  <ArrowRight size={19} />
                </Link>
              </div>
            </div>

            <div className="glass-panel rounded-md p-6">
              <div className="mb-5 flex items-center justify-between">
                <div>
                  <p className="text-xs font-extrabold uppercase tracking-[0.2em] text-clinical">Control SUMIMEDIC</p>
                  <h2 className="mt-2 font-[var(--font-manrope)] text-2xl font-extrabold">Operacion trazable</h2>
                </div>
                <span className="rounded-md bg-pulse/10 px-3 py-2 text-xs font-extrabold text-pulse">Proveedor auditado</span>
              </div>
              <div className="grid gap-3">
                {trackingStages.map((stage, index) => (
                  <div key={stage.status} className="grid gap-4 rounded-md border border-slate-200 bg-white p-4 md:grid-cols-[42px_1fr_auto] md:items-center">
                    <span className="grid h-10 w-10 place-items-center rounded-md bg-ink text-sm font-extrabold text-white">{index + 1}</span>
                    <div>
                      <h3 className="font-extrabold text-ink">{stage.status}</h3>
                      <p className="text-sm leading-6 text-slate-600">{stage.detail}</p>
                    </div>
                    <div className="text-left md:text-right">
                      <p className="text-xs font-extrabold uppercase tracking-[0.16em] text-clinical">{stage.owner}</p>
                      <p className="mt-1 text-sm font-bold text-slate-500">{stage.eta}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="bg-white py-16">
          <div className="container-premium grid gap-5 md:grid-cols-3">
            {[
              { icon: ShieldCheck, title: "Control empresarial", text: "SUMIMEDIC valida, aprueba, cotiza y mantiene la relacion comercial." },
              { icon: FileCheck2, title: "Cumplimiento documental", text: "Ficha tecnica, certificado sanitario, garantia y validacion regulatoria por producto." },
              { icon: Truck, title: "SLA logistico", text: "Tracking profesional, proveedor asignado, incidencias y entrega validada." }
            ].map((item) => {
              const Icon = item.icon;
              return (
                <article key={item.title} className="rounded-md border border-slate-200 bg-white p-6 shadow-sm">
                  <Icon className="text-clinical" size={30} />
                  <h2 className="mt-5 font-[var(--font-manrope)] text-xl font-extrabold">{item.title}</h2>
                  <p className="mt-3 text-sm leading-7 text-slate-600">{item.text}</p>
                </article>
              );
            })}
          </div>
        </section>

        <section className="bg-sterile py-20">
          <div className="container-premium">
            <SectionHeading
              eyebrow="Trazabilidad operativa visible"
              title="Cada abastecimiento queda gobernado por evidencias, responsables y SLA."
              text="El cliente no ve un marketplace abierto. Ve una operacion SUMIMEDIC con control documental, proveedor certificado, tracking, incidencias, entrega validada y seguimiento CRM."
              align="center"
            />
            <div className="mt-10 grid gap-5 lg:grid-cols-[.95fr_1.05fr]">
              <div className="rounded-md border border-slate-200 bg-white p-6 shadow-premium">
                <div className="mb-6 flex items-center justify-between">
                  <div>
                    <p className="text-xs font-extrabold uppercase tracking-[0.2em] text-clinical">Orden SCAS-2481</p>
                    <h3 className="mt-2 font-[var(--font-manrope)] text-2xl font-extrabold text-ink">Tracking profesional</h3>
                  </div>
                  <Radar className="text-clinical" size={30} />
                </div>
                <div className="grid gap-3">
                  {[
                    ["Inventario local validado", "SUMIMEDIC Central", "Completado"],
                    ["Proveedor certificado confirmado", "Proveedor Biomedico Norte", "Completado"],
                    ["Aprobacion operativa", "Control SUMIMEDIC", "En curso"],
                    ["Cotizacion formal", "Asesor institucional", "Pendiente"],
                    ["Surtido controlado", "Red autorizada", "Pendiente"],
                    ["Entrega validada", "Cliente B2B", "Pendiente"]
                  ].map(([step, owner, status]) => (
                    <div key={step} className="grid gap-3 rounded-md border border-slate-200 bg-slate-50 p-4 md:grid-cols-[1fr_auto] md:items-center">
                      <div>
                        <p className="font-extrabold text-ink">{step}</p>
                        <p className="mt-1 text-sm font-semibold text-slate-500">{owner}</p>
                      </div>
                      <span className={`rounded-md px-3 py-2 text-xs font-extrabold ${status === "Completado" ? "bg-pulse/10 text-pulse" : status === "En curso" ? "bg-amber-100 text-amber-700" : "bg-slate-100 text-slate-600"}`}>
                        {status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid gap-5 md:grid-cols-2">
                {[
                  { icon: ClipboardList, title: "Expediente documental", text: "Ficha tecnica, certificado sanitario, garantia, lote, proveedor y aprobacion interna." },
                  { icon: MapPinned, title: "Ruta y cobertura", text: "Zona de surtido, SLA por region, responsable logistico y tiempo estimado real." },
                  { icon: FileCheck2, title: "Validacion regulatoria", text: "Control de compatibilidades, documentos descargables y evidencia para auditoria." },
                  { icon: Truck, title: "Incidencias y entrega", text: "Registro de desviaciones, soporte especializado y validacion de recepcion." }
                ].map((item) => {
                  const Icon = item.icon;
                  return (
                    <article key={item.title} className="rounded-md border border-slate-200 bg-white p-6 shadow-sm">
                      <Icon className="text-clinical" size={28} />
                      <h3 className="mt-4 text-lg font-extrabold text-ink">{item.title}</h3>
                      <p className="mt-2 text-sm leading-7 text-slate-600">{item.text}</p>
                    </article>
                  );
                })}
              </div>
            </div>
          </div>
        </section>

        <section className="bg-ink py-20 text-white">
          <div className="container-premium">
            <SectionHeading
              eyebrow="Flujo operativo obligatorio"
              title="Disponibilidad ampliada sin perder control institucional."
              text="Cada solicitud se gobierna por reglas de inventario, proveedores certificados, aprobacion SUMIMEDIC, cotizacion formal, seguimiento logistico y CRM."
              align="center"
              tone="dark"
            />
            <div className="mt-12 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {supplyChainFlow.map((step, index) => (
                <article key={step.title} className="rounded-md border border-white/10 bg-white/10 p-5">
                  <span className="grid h-9 w-9 place-items-center rounded-md bg-cyan-300 text-sm font-extrabold text-ink">
                    {index + 1}
                  </span>
                  <h3 className="mt-5 font-[var(--font-manrope)] text-lg font-extrabold">{step.title}</h3>
                  <p className="mt-3 text-sm leading-7 text-slate-300">{step.text}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="bg-sterile py-20">
          <div className="container-premium">
            <SectionHeading
              eyebrow="Red certificada"
              title="Proveedores autorizados, auditados y controlados."
              text="El sistema no permite proveedores no auditados. Cada aliado opera con expediente documental, score de confiabilidad, SLA, cobertura y categoria especializada."
              align="center"
            />
            <div className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
              {supplierControls.map((control) => {
                const Icon = control.icon;
                return (
                  <article key={control.title} className="rounded-md border border-slate-200 bg-white p-6 shadow-sm">
                    <Icon className="text-clinical" size={28} />
                    <h3 className="mt-4 text-lg font-extrabold text-ink">{control.title}</h3>
                    <p className="mt-2 text-sm leading-7 text-slate-600">{control.text}</p>
                  </article>
                );
              })}
            </div>
          </div>
        </section>

        <section className="bg-white py-20">
          <div className="container-premium grid gap-10 lg:grid-cols-[.9fr_1.1fr] lg:items-start">
            <SectionHeading
              eyebrow="Inventario sincronizado"
              title="Evitar sobreventa es parte del producto."
              text="La disponibilidad extendida solo se comunica cuando existe confirmacion propia o aliada, tiempo estimado real y aprobacion operativa interna."
            />
            <div className="grid gap-5">
              {inventoryControls.map((item) => {
                const Icon = item.icon;
                return (
                  <article key={item.title} className="rounded-md border border-slate-200 bg-slate-50 p-6">
                    <div className="flex gap-4">
                      <span className="grid h-12 w-12 shrink-0 place-items-center rounded-md bg-white text-clinical shadow-sm">
                        <Icon size={24} />
                      </span>
                      <div>
                        <h3 className="text-lg font-extrabold text-ink">{item.title}</h3>
                        <p className="mt-2 text-sm leading-7 text-slate-600">{item.text}</p>
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          </div>
        </section>

        <section className="bg-sterile py-20">
          <div className="container-premium grid gap-10 lg:grid-cols-[1fr_.95fr] lg:items-center">
            <div className="rounded-md border border-slate-200 bg-white p-6 shadow-premium">
              <div className="mb-6 flex items-center justify-between">
                <div>
                  <p className="text-xs font-extrabold uppercase tracking-[0.2em] text-clinical">Panel B2B privado</p>
                  <h2 className="mt-2 font-[var(--font-manrope)] text-2xl font-extrabold">Gestion de Abastecimiento</h2>
                </div>
                <LockKeyhole className="text-clinical" size={28} />
              </div>
              <div className="grid gap-3">
                {[
                  ["Historial", "Pedidos abiertos, proveedores asignados y evidencia documental."],
                  ["Recurrencia", "Reposicion automatica por consumo, frecuencia y minimos."],
                  ["Incidencias", "Soporte especializado, SLA y seguimiento ejecutivo."],
                  ["CRM", "Alertas de recompra, remarketing B2B y atencion por cuenta."]
                ].map(([title, text]) => (
                  <div key={title} className="rounded-md border border-slate-200 bg-slate-50 p-4">
                    <p className="font-extrabold text-ink">{title}</p>
                    <p className="mt-1 text-sm leading-6 text-slate-600">{text}</p>
                  </div>
                ))}
              </div>
            </div>
            <SectionHeading
              eyebrow="Recompra y escalabilidad"
              title="El valor no termina en la entrega."
              text="Cada pedido alimenta historial comercial, alertas de reposicion, frecuencia de consumo, seguimiento ejecutivo y oportunidades de contrato recurrente."
            />
          </div>
        </section>

        <section className="bg-white py-16">
          <div className="container-premium rounded-md border border-slate-200 bg-ink p-8 text-white shadow-premium md:p-10">
            <div className="grid gap-8 lg:grid-cols-[1fr_auto] lg:items-center">
              <div>
                <div className="mb-5 inline-flex items-center gap-2 rounded-md bg-white/10 px-3 py-2 text-xs font-extrabold uppercase tracking-[0.18em] text-cyan-100">
                  <BadgeCheck size={16} />
                  Ventaja competitiva
                </div>
                <h2 className="font-[var(--font-manrope)] text-3xl font-extrabold md:text-5xl">
                  Abastecimiento medico sin interrupciones, con control SUMIMEDIC.
                </h2>
              </div>
              <Link href="/contacto" className="inline-flex h-14 items-center justify-center gap-2 rounded-md bg-white px-6 text-sm font-extrabold text-ink transition hover:bg-cyan-50">
                Activar red certificada
                <ArrowRight size={19} />
              </Link>
            </div>
          </div>
        </section>

        <CtaBand />
      </main>
    </>
  );
}
