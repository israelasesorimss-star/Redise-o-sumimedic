# Correcciones aplicadas

## Errores corregidos

1. Error: sharp is required
2. Error: upstream image response failed
3. Compatibilidad para Hostinger standalone
4. Compatibilidad para despliegue en Vercel
5. Preparación para GitHub CI/CD

## Cambios

- agregado sharp
- output standalone
- images.unoptimized = true
- remotePatterns para Unsplash
- soporte plus.unsplash.com

## Ejecutar

npm install
npm run build
npm run start

## Recomendación

Mover imágenes críticas a /public/images en formato WebP.
